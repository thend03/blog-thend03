/*
 * @FilePath: icons.js
 * @Author: zhangyuehua88
 * @Date: 2022-06-22 16:46:38
 * @LastEditors: zhangyuehua88
 * @LastEditTime: 2022-12-27 10:30:39
 */
(function () {
  window.__iconpark__ = window.__iconpark__ || {};
  var obj = JSON.parse(
    '{"31112":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" fill-opacity=\\".01\\" fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\"/><path data-follow-stroke=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"M37 18 25 30 13 18\\"/></g>"},"31114":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\" fill=\\"currentColor\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"m19 12 12 12-12 12\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"31115":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M21 38c9.389 0 17-7.611 17-17S30.389 4 21 4 4 11.611 4 21s7.611 17 17 17z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M26.657 14.343A7.975 7.975 0 0 0 21 12c-2.21 0-4.21.895-5.657 2.343m17.879 18.879 8.485 8.485\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"31121":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path d=\\"M24 4c-7.732 0-14 6.268-14 14v20h28V18c0-7.732-6.268-14-14-14z\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M10 38V18c0-7.732 6.268-14 14-14s14 6.268 14 14v20M4 38h40m-20 6a5 5 0 0 0 5-5v-1H19v1a5 5 0 0 0 5 5z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"31135":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-stroke=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"M18 6H8a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2ZM18 28H8a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V30a2 2 0 0 0-2-2ZM40 6H30a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2ZM40 28H30a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V30a2 2 0 0 0-2-2Z\\"/></g>"},"31136":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" data-follow-fill=\\"currentColor\\" d=\\"M24 44c11.046 0 20-8.954 20-20S35.046 4 24 4 4 12.954 4 24s8.954 20 20 20z\\" fill=\\"currentColor\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/><path d=\\"M24 16v16m-8-8h16\\" stroke=\\"#FFF\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"31137":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M8 11h32M8 24h32M8 37h32m-26.343-7.343L8 24l5.657-5.657\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"31138":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M8 11h32M8 24h34M8 37h32m-3.657-7.343L42 24l-5.657-5.657\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"31149":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\" fill=\\"currentColor\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"m24.06 10-.036 28M10 24h28\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"31150":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path d=\\"M18.284 43.171a19.995 19.995 0 0 1-8.696-5.304 6 6 0 0 0-5.182-9.838A20.09 20.09 0 0 1 4 24c0-2.09.32-4.106.916-6H5a6 6 0 0 0 5.385-8.65 19.968 19.968 0 0 1 8.267-4.627A6 6 0 0 0 24 8a6 6 0 0 0 5.348-3.277 19.968 19.968 0 0 1 8.267 4.627A6 6 0 0 0 43.084 18 19.99 19.99 0 0 1 44 24c0 1.38-.14 2.728-.406 4.029a6 6 0 0 0-5.182 9.838 19.995 19.995 0 0 1-8.696 5.304 6.003 6.003 0 0 0-11.432 0z\\" stroke=\\"#666\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/><path d=\\"M24 31a7 7 0 1 0 0-14 7 7 0 0 0 0 14z\\" stroke=\\"#666\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/></g>"},"31212":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><circle cx=\\"12\\" cy=\\"24\\" r=\\"3\\" fill=\\"#666\\"/><circle cx=\\"24\\" cy=\\"24\\" r=\\"3\\" fill=\\"#666\\"/><circle cx=\\"36\\" cy=\\"24\\" r=\\"3\\" fill=\\"#666\\"/></g>"},"31300":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\" fill=\\"currentColor\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" data-follow-fill=\\"currentColor\\" d=\\"M36 19 24 31 12 19h24z\\" fill=\\"currentColor\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/></g>"},"31302":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" fill-opacity=\\".01\\" fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\"/><path data-follow-stroke=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"m14 14 20 20m-20 0 20-20\\"/></g>"},"31304":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-stroke=\\"currentColor\\" d=\\"M13 12.432v-4.62A2.813 2.813 0 0 1 15.813 5h24.374A2.813 2.813 0 0 1 43 7.813v24.375A2.813 2.813 0 0 1 40.187 35h-4.67\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M32.188 13H7.811A2.813 2.813 0 0 0 5 15.813v24.374A2.813 2.813 0 0 0 7.813 43h24.375A2.813 2.813 0 0 0 35 40.187V15.814A2.813 2.813 0 0 0 32.187 13z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/></g>"},"31306":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-stroke=\\"currentColor\\" d=\\"M40 33v9a2 2 0 0 1-2 2h-6.5M40 16V6a2 2 0 0 0-2-2H10a2 2 0 0 0-2 2v36a2 2 0 0 0 2 2h6\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M16 16h14m-7 28 17-21m-24 1h8\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\"/></g>"},"31307":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\" fill=\\"currentColor\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M9 10v34h30V10H9z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M20 20v13m8-13v13M4 10h40\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"m16 10 3.289-6h9.488L32 10H16z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/></g>"},"31557":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" fill=\\"currentColor\\" d=\\"M19 10a4 4 0 1 1-8 0 4 4 0 0 1 8 0Zm-4 18a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm0 14a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM37 10a4 4 0 1 1-8 0 4 4 0 0 1 8 0Zm-4 18a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm0 14a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z\\" clip-rule=\\"evenodd\\" fill-rule=\\"evenodd\\"/></g>"},"31582":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" fill-opacity=\\".01\\" fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\"/><path data-follow-stroke=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"M43 11 16.875 37 5 25.182\\"/></g>"},"31743":{"viewBox":"0 0 16 16","content":"<g><g stroke-width=\\"2\\" stroke=\\"#455166\\" fill-rule=\\"evenodd\\" fill=\\"none\\"><circle r=\\"7\\" cy=\\"8\\" cx=\\"8\\"/><path opacity=\\".5\\" d=\\"m3.866 7.69 2.196 2.342 2.596-4.176 1.685 2.337h2.523\\"/></g></g>"},"31744":{"viewBox":"0 0 16 16","content":"<g><g stroke-width=\\"2\\" stroke=\\"#455166\\" fill-rule=\\"evenodd\\" fill=\\"none\\"><path d=\\"m8 1.155 5.928 3.422v6.846L8 14.845l-5.928-3.422V4.577L8 1.155z\\"/><path opacity=\\".5\\" d=\\"M5 6.75 8 8.5l3-1.75\\"/></g></g>"},"31745":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><rect rx=\\"1\\" height=\\"10\\" width=\\"14\\" y=\\"1.5\\" x=\\"1\\" stroke-width=\\"2\\" stroke=\\"#455166\\"/><path opacity=\\".5\\" fill=\\"#455166\\" d=\\"M4 6.5h2V9H4zM7 4h2v5H7zM10 5.25h2V9h-2z\\"/><path fill=\\"#455166\\" d=\\"M4 13.5h8v2H4z\\"/></g></g>"},"31746":{"viewBox":"0 0 16 16","content":"<g><g stroke-width=\\"2\\" stroke=\\"#455166\\" fill-rule=\\"evenodd\\" fill=\\"none\\"><rect rx=\\"1\\" height=\\"5\\" width=\\"5\\" y=\\"1\\" x=\\"1\\"/><rect rx=\\"1\\" height=\\"5\\" width=\\"5\\" y=\\"10\\" x=\\"10\\"/><path opacity=\\".5\\" d=\\"M7.922 4H12v4.175M8.088 12H4V8\\"/></g></g>"},"31747":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><rect rx=\\"1\\" height=\\"10\\" width=\\"10\\" y=\\"5\\" x=\\"1\\" stroke-width=\\"2\\" stroke=\\"#455166\\"/><path fill=\\"#455166\\" d=\\"M1 8h10v2H1z\\"/><path opacity=\\".5\\" stroke-width=\\"2\\" stroke=\\"#455166\\" d=\\"M3 .782h10.997a1 1 0 0 1 1 1V12.5\\"/></g></g>"},"31748":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path stroke-width=\\"2\\" stroke=\\"#455166\\" d=\\"m4.672 11.464-3-3.5 3-3.5\\"/><path opacity=\\".5\\" fill=\\"#455166\\" d=\\"M8.07 2.878 10 3.395l-2.588 9.66-1.932-.518z\\"/><path stroke-width=\\"2\\" stroke=\\"#455166\\" d=\\"m11.5 11.464 2.828-3.5-2.828-3.5\\"/></g></g>"},"31749":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><rect rx=\\"1\\" height=\\"14\\" width=\\"12\\" y=\\"1\\" x=\\"2\\" stroke-width=\\"2\\" stroke=\\"#455166\\"/><path opacity=\\".5\\" fill=\\"#455166\\" d=\\"M4 7h5.25v2H4zM4 10h7v2H4z\\"/><path fill=\\"#455166\\" d=\\"M7.5 1h4v5l-2-1.135L7.5 6z\\"/></g></g>"},"31750":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path stroke-width=\\"2\\" stroke=\\"#455166\\" d=\\"M9.895 1.78A6.454 6.454 0 0 0 8 1.5a6.5 6.5 0 1 0 6.201 4.547\\"/><path stroke-width=\\"2\\" stroke=\\"#455166\\" d=\\"M8 5a3 3 0 1 0 3 3\\"/><path opacity=\\".5\\" fill=\\"#455166\\" d=\\"m15.95 2.879-3.394 3.394-1.147-.268-2.53 2.53a1 1 0 0 1-1.415-1.414l2.56-2.559-.297-1.118L13.121.05l.473 2.356 2.356.473z\\"/></g></g>"},"31751":{"viewBox":"0 0 16 16","content":"<g><path d=\\"M1.5 6.5h3v3h-3zm5 0h3v3h-3zm5 0h3v3h-3z\\" data-follow-fill=\\"#455166\\" fill=\\"#455166\\" fill-rule=\\"evenodd\\"/></g>"},"31752":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"#455166\\" fill-rule=\\"evenodd\\"><path opacity=\\".5\\" d=\\"M0 14h16v2H0z\\"/><path d=\\"M1 6.4h2V13H1zM5 4.2h2V13H5zM9 7.5h2V13H9zM13 2h2v11h-2z\\"/></g></g>"},"31753":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path stroke-width=\\"2\\" stroke=\\"#455166\\" d=\\"m6.483 2 2.04 2.5H15V14H1V2h5.483z\\"/><circle r=\\"1\\" cy=\\"9\\" cx=\\"4\\" opacity=\\".5\\" fill=\\"#455166\\"/><path opacity=\\".5\\" fill=\\"#455166\\" d=\\"M6 8h7v2H6z\\"/></g></g>"},"31754":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path stroke-width=\\"2\\" stroke=\\"#455166\\" d=\\"m14.845 8-3.422 5.928H4.577L1.155 8l3.422-5.928h6.846L14.845 8z\\"/><path opacity=\\".5\\" fill=\\"#455166\\" d=\\"m11 8-1.5 2.598h-3L5 8l1.5-2.598h3z\\"/></g></g>"},"31755":{"viewBox":"0 0 16 16","content":"<g><g stroke-width=\\"2\\" stroke=\\"#FFF\\" fill-rule=\\"evenodd\\" fill=\\"none\\"><path d=\\"m8 1.155 5.928 3.422v6.846L8 14.845l-5.928-3.422V4.577L8 1.155z\\"/><path opacity=\\".5\\" d=\\"M5 6.75 8 8.5l3-1.75\\"/></g></g>"},"31756":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path stroke-width=\\"2\\" stroke=\\"#FFF\\" d=\\"m14.845 8-3.422 5.928H4.577L1.155 8l3.422-5.928h6.846L14.845 8z\\"/><path opacity=\\".5\\" fill=\\"#FFF\\" d=\\"m11 8-1.5 2.598h-3L5 8l1.5-2.598h3z\\"/></g></g>"},"31757":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><rect rx=\\"1\\" height=\\"14\\" width=\\"12\\" y=\\"1\\" x=\\"2\\" stroke-width=\\"2\\" stroke=\\"#FFF\\"/><path opacity=\\".5\\" fill=\\"#FFF\\" d=\\"M4 7h5.25v2H4zM4 10h7v2H4z\\"/><path fill=\\"#FFF\\" d=\\"M7.5 1h4v5l-2-1.135L7.5 6z\\"/></g></g>"},"31758":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path stroke-width=\\"2\\" stroke=\\"#FFF\\" d=\\"m4.672 11.464-3-3.5 3-3.5\\"/><path opacity=\\".5\\" fill=\\"#FFF\\" d=\\"M8.07 2.878 10 3.395l-2.588 9.66-1.932-.518z\\"/><path stroke-width=\\"2\\" stroke=\\"#FFF\\" d=\\"m11.5 11.464 2.828-3.5-2.828-3.5\\"/></g></g>"},"31759":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><rect rx=\\"1\\" height=\\"10\\" width=\\"14\\" y=\\"1.5\\" x=\\"1\\" stroke-width=\\"2\\" stroke=\\"#FFF\\"/><path opacity=\\".5\\" fill=\\"#FFF\\" d=\\"M4 6.5h2V9H4zM7 4h2v5H7zM10 5.25h2V9h-2z\\"/><path fill=\\"#FFF\\" d=\\"M4 13.5h8v2H4z\\"/></g></g>"},"31760":{"viewBox":"0 0 16 16","content":"<g><path d=\\"M1.5 6.5h3v3h-3zm5 0h3v3h-3zm5 0h3v3h-3z\\" data-follow-fill=\\"#FFF\\" fill=\\"#FFF\\" fill-rule=\\"evenodd\\"/></g>"},"31761":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"#FFF\\" fill-rule=\\"evenodd\\"><path opacity=\\".5\\" d=\\"M0 14h16v2H0z\\"/><path d=\\"M1 6.4h2V13H1zM5 4.2h2V13H5zM9 7.5h2V13H9zM13 2h2v11h-2z\\"/></g></g>"},"31762":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path stroke-width=\\"2\\" stroke=\\"#FFF\\" d=\\"M9.895 1.78A6.454 6.454 0 0 0 8 1.5a6.5 6.5 0 1 0 6.201 4.547\\"/><path stroke-width=\\"2\\" stroke=\\"#FFF\\" d=\\"M8 5a3 3 0 1 0 3 3\\"/><path opacity=\\".5\\" fill=\\"#FFF\\" d=\\"m15.95 2.879-3.394 3.394-1.147-.268-2.53 2.53a1 1 0 0 1-1.415-1.414l2.56-2.559-.297-1.118L13.121.05l.473 2.356 2.356.473z\\"/></g></g>"},"31763":{"viewBox":"0 0 16 16","content":"<g><g stroke-width=\\"2\\" stroke=\\"#FFF\\" fill-rule=\\"evenodd\\" fill=\\"none\\"><rect rx=\\"1\\" height=\\"5\\" width=\\"5\\" y=\\"1\\" x=\\"1\\"/><rect rx=\\"1\\" height=\\"5\\" width=\\"5\\" y=\\"10\\" x=\\"10\\"/><path opacity=\\".5\\" d=\\"M7.922 4H12v4.175M8.088 12H4V8\\"/></g></g>"},"31764":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path stroke-width=\\"2\\" stroke=\\"#FFF\\" d=\\"m6.483 2 2.04 2.5H15V14H1V2h5.483z\\"/><circle r=\\"1\\" cy=\\"9\\" cx=\\"4\\" opacity=\\".5\\" fill=\\"#FFF\\"/><path opacity=\\".5\\" fill=\\"#FFF\\" d=\\"M6 8h7v2H6z\\"/></g></g>"},"31765":{"viewBox":"0 0 16 16","content":"<g><g stroke-width=\\"2\\" stroke=\\"#FFF\\" fill-rule=\\"evenodd\\" fill=\\"none\\"><circle r=\\"7\\" cy=\\"8\\" cx=\\"8\\"/><path opacity=\\".5\\" d=\\"m3.866 7.69 2.196 2.342 2.596-4.176 1.685 2.337h2.523\\"/></g></g>"},"31766":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><rect rx=\\"1\\" height=\\"10\\" width=\\"10\\" y=\\"5\\" x=\\"1\\" stroke-width=\\"2\\" stroke=\\"#FFF\\"/><path fill=\\"#FFF\\" d=\\"M1 8h10v2H1z\\"/><path opacity=\\".5\\" stroke-width=\\"2\\" stroke=\\"#FFF\\" d=\\"M3 .782h10.997a1 1 0 0 1 1 1V12.5\\"/></g></g>"},"31768":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path d=\\"M0 0h16v16H0z\\" fill-rule=\\"nonzero\\" fill-opacity=\\".01\\" fill=\\"#FFF\\"/><rect rx=\\"2\\" height=\\"16\\" width=\\"16\\" fill=\\"#E0EFFF\\"/><path stroke-width=\\"2\\" stroke=\\"#3693FF\\" d=\\"M8 2.3c1.105 0 2.105.448 2.828 1.172a4 4 0 0 1-.827 6.293V10.8H6V9.765a4 4 0 0 1-.828-6.293A3.987 3.987 0 0 1 8 2.3zM5 13.8h6\\"/></g></g>"},"31769":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path d=\\"M0 0h16v16H0z\\" fill-rule=\\"nonzero\\" fill-opacity=\\".01\\" fill=\\"#FFF\\"/><rect rx=\\"2\\" height=\\"16\\" width=\\"16\\" fill=\\"#D2F9F4\\"/><path fill=\\"#2EC6C1\\" d=\\"M4 9.5v2H2v-2h2zm10 0v2H6v-2h8zm-10-5v2H2v-2h2zm10 0v2H6v-2h8z\\"/></g></g>"},"31770":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\" d=\\"M0 0h16v16H0z\\"/><rect fill=\\"#FFEBCC\\" width=\\"16\\" height=\\"16\\" rx=\\"2\\"/><circle stroke=\\"#F90\\" stroke-width=\\"2\\" cx=\\"8\\" cy=\\"8\\" r=\\"5\\"/></g></g>"},"31771":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h16v16H0z\\"/><path fill=\\"#9CD813\\" stroke=\\"#9CD813\\" d=\\"M8 14.667A6.667 6.667 0 1 0 8 1.333a6.667 6.667 0 0 0 0 13.334z\\"/><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"1.333\\" stroke=\\"#FFF\\" d=\\"m11 7-3 3-3-3\\"/></g></g>"},"31773":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h16v16H0z\\"/><path fill=\\"#F90\\" stroke=\\"#F90\\" d=\\"M8 14.667A6.667 6.667 0 1 0 8 1.333a6.667 6.667 0 0 0 0 13.334z\\"/><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"1.333\\" stroke=\\"#FFF\\" d=\\"M11 9 8 6 5 9\\"/></g></g>"},"31775":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h16v16H0z\\"/><path fill=\\"#FAD414\\" stroke=\\"#FAD414\\" d=\\"M8 14.667A6.667 6.667 0 1 0 8 1.333a6.667 6.667 0 0 0 0 13.334z\\"/><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"1.333\\" stroke=\\"#FFF\\" d=\\"M5.333 8h5.334\\"/></g></g>"},"32084":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" fill-opacity=\\".01\\" fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\"/><path data-follow-stroke=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"M36.728 36.728A17.943 17.943 0 0 1 24 42c-9.941 0-18-8.059-18-18S14.059 6 24 6c4.97 0 9.47 2.015 12.728 5.272C38.386 12.93 42 17 42 17\\"/><path data-follow-stroke=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"M42 8v9h-9\\"/></g>"},"34430":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-stroke=\\"currentColor\\" d=\\"M42 25H30m6-6-6 6 6 6M21 6v20c0 6.74-6.165 13.567-12 16\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M42 14V9a3 3 0 0 0-3-3H9a3 3 0 0 0-3 3v30a3 3 0 0 0 3 3h30a3 3 0 0 0 3-3v-3.5\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"34431":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-stroke=\\"currentColor\\" d=\\"M30 25h12m-6-6 6 6-6 6M21 6v20c0 6.74-6.165 13.567-12 16\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M42 14V9a3 3 0 0 0-3-3H9a3 3 0 0 0-3 3v30a3 3 0 0 0 3 3h30a3 3 0 0 0 3-3v-3.5\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"34432":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M30 6h12v12M18 6H6v12m24 24h12V30M18 42H6V30M42 6 29 19M19 29 6 42\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"34433":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path d=\\"M48 0H0v48h48V0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M41 19H29V7M18 6H6v12m24 24h12V30M7 29h12v12M42 6 29 19M19 29 6 42\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"34617":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"m8 36 .004-7.957c.001-.552.449-1 1-1h10.003c.921 0 .916-.818.916-2.764 0-1.946-4.901-3.585-4.901-10.426S20.1 5 24.32 5s8.816 2.012 8.816 8.853c0 6.841-4.876 7.929-4.876 10.426s0 2.764.781 2.764h9.96a1 1 0 0 1 1 1V36H8z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M8 42h32\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"34822":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\" fill=\\"currentColor\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M30 19H20a8 8 0 1 0 0 16h16a8 8 0 0 0 6-13.292\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M6 24.292A8 8 0 0 1 12 11h16a8 8 0 1 1 0 16H18\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"34900":{"viewBox":"0 0 48 48","fill":"none","content":"<g><rect width=\\"48\\" height=\\"48\\" fill=\\"white\\" fill-opacity=\\"0.01\\"/><path d=\\"M6 24.0083V42H42V24\\" stroke=\\"#666\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path d=\\"M33 23L24 32L15 23\\" stroke=\\"#666\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path d=\\"M23.9917 6V32\\" stroke=\\"#666\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"35816":{"viewBox":"0 0 48 48","fill":"none","content":"<g><rect width=\\"48\\" height=\\"48\\" fill=\\"white\\" fill-opacity=\\"0.01\\"/><path d=\\"M23.9986 5L17.8856 17.4776L4 19.4911L14.0589 29.3251L11.6544 43L23.9986 36.4192L36.3454 43L33.9586 29.3251L44 19.4911L30.1913 17.4776L23.9986 5Z\\" fill=\\"#f6e72b\\" stroke=\\"#f6e72b\\" stroke-width=\\"4\\" stroke-linejoin=\\"bevel\\"/></g>"},"35817":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path fill-opacity=\\".01\\" fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\"/><path data-follow-stroke=\\"#333\\" stroke-linejoin=\\"bevel\\" stroke-width=\\"4\\" stroke=\\"#333\\" d=\\"m23.999 5-6.113 12.478L4 19.49l10.059 9.834L11.654 43 24 36.42 36.345 43 33.96 29.325 44 19.491l-13.809-2.013L24 5z\\"/></g>"},"36261":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path fill-opacity=\\".01\\" fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\"/><path data-follow-stroke=\\"#333\\" stroke-linejoin=\\"bevel\\" stroke-width=\\"4\\" stroke=\\"#333\\" d=\\"M5.325 43.5h8.485l31.113-31.113-8.486-8.485L5.325 35.015V43.5z\\"/><path data-follow-stroke=\\"#333\\" stroke-linejoin=\\"bevel\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"#333\\" d=\\"m27.952 12.387 8.485 8.486\\"/></g>"},"37127":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path fill-opacity=\\".01\\" fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\"/><mask style=\\"mask-type:alpha\\" height=\\"48\\" width=\\"48\\" y=\\"0\\" x=\\"0\\" maskUnits=\\"userSpaceOnUse\\" id=\\"a\\"><path data-follow-fill=\\"#666\\" fill=\\"#666\\" d=\\"M0 0h48v48H0z\\"/></mask><g mask=\\"url(#a)\\" stroke-linejoin=\\"bevel\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"#666\\"><path data-follow-stroke=\\"#666\\" d=\\"M6 24.008V42h36V24M33 15l-9-9-9 9M23.992 32V6\\"/></g></g>"},"37638":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path d=\\"M0 0h16v16H0z\\" fill-rule=\\"nonzero\\" fill-opacity=\\".01\\" fill=\\"#FFF\\"/><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h16v16H0z\\"/><g fill-rule=\\"nonzero\\"><path fill=\\"#E5E5E5\\" d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2z\\"/><path fill=\\"#CCC\\" d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75z\\"/></g><path fill=\\"#999\\" d=\\"M8.229 10.473c.126 0 .227.096.227.214v.6c0 .117-.101.213-.227.213H7.66c-.125 0-.227-.096-.227-.214v-.599c0-.118.102-.214.227-.214h.569zM8.096 5.5c.568 0 1.03.14 1.38.435.35.288.524.682.524 1.183 0 .41-.114.748-.323 1.01-.079.083-.332.304-.751.65a1.29 1.29 0 0 0-.35.41 1.104 1.104 0 0 0-.13.534v.115H7.44v-.115c0-.312.052-.583.175-.805.113-.222.454-.567 1.022-1.043l.104-.115a.879.879 0 0 0 .236-.583c0-.271-.087-.485-.244-.641-.166-.156-.402-.23-.7-.23-.383 0-.654.107-.82.337-.148.189-.218.46-.218.805H6c0-.608.183-1.085.568-1.43.375-.345.882-.517 1.528-.517z\\"/></g></g>"},"37639":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path d=\\"M0 0h16v16H0z\\" fill-rule=\\"nonzero\\" fill-opacity=\\".01\\" fill=\\"#FFF\\"/><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h16v16H0z\\"/><path fill=\\"#70B2FF\\" d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2z\\"/><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" d=\\"M4.5 6.5h.972l.972 3.558h.012L7.524 6.5h.936l1.08 3.558.984-3.558h.936l-1.44 4.585h-.972L7.98 7.562h-.012l-1.08 3.511h-.972z\\"/><path fill=\\"#E0EFFF\\" d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75z\\"/></g></g>"},"37640":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"nonzero\\" fill=\\"none\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h16v16H0z\\"/><path fill=\\"#5ACC9B\\" d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2z\\"/><path fill=\\"#BDEBD7\\" d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75z\\"/><path fill=\\"#FFF\\" d=\\"M7.448 8.4 5.816 6.025h1.128l1.068 1.7 1.116-1.7h1.092L8.552 8.4l1.752 2.525h-1.14l-1.176-1.8-1.176 1.813H5.696z\\"/></g></g>"},"37641":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"nonzero\\" fill=\\"none\\"><path d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\"/><path fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h16v16H0z\\"/><path fill=\\"#FF5562\\" d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2z\\"/><path fill=\\"#FFF\\" d=\\"M10.37 12.278c-.756 0-1.428-1.26-1.788-2.077a13.29 13.29 0 0 0-1.896-.618c-.564.362-1.512.898-2.244.898-.456 0-.78-.221-.9-.606-.096-.315-.012-.537.084-.654.192-.256.588-.385 1.188-.385.48 0 1.092.082 1.776.245.444-.303.888-.653 1.284-1.026-.18-.817-.372-2.135.12-2.742.24-.292.612-.385 1.056-.257.492.14.672.432.732.654.204.793-.732 1.866-1.368 2.496.144.549.324 1.12.552 1.645.912.397 1.992.98 2.112 1.622.048.222-.024.432-.204.607a.786.786 0 0 1-.504.198zm-1.116-1.773c.456.898.888 1.318 1.116 1.318.036 0 .084-.012.156-.07.084-.082.084-.14.072-.187-.048-.233-.432-.618-1.344-1.061zm-4.44-1.202c-.588 0-.756.14-.804.198-.012.024-.06.082-.012.245.036.14.132.28.444.28.384 0 .936-.21 1.584-.583a6.363 6.363 0 0 0-1.212-.14zm2.376-.07c.384.105.78.233 1.152.373-.132-.338-.24-.688-.336-1.026-.264.221-.54.443-.816.653zm1.488-3.768a.392.392 0 0 0-.312.14c-.252.303-.276 1.073-.084 2.053C9.014 6.9 9.41 6.2 9.314 5.826c-.012-.058-.06-.221-.396-.315a.67.67 0 0 0-.24-.046z\\"/><path fill=\\"#FFBBC0\\" d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75z\\"/></g></g>"},"37642":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"nonzero\\" fill=\\"none\\"><path d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\"/><path fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h16v16H0z\\"/><path fill=\\"#FF8976\\" d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2z\\"/><path fill=\\"#FFF\\" d=\\"M6 6h2.64c1.056 0 1.392.688 1.392 1.423 0 .7-.42 1.412-1.38 1.412H6.9v1.75H6V6zm.9 2.123h1.452c.516 0 .792-.151.792-.688 0-.56-.372-.7-.72-.7H6.9v1.388z\\"/><path fill=\\"#FFD0C8\\" d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75z\\"/></g></g>"},"37643":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"nonzero\\" fill=\\"none\\"><path d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\"/><path fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h16v16H0z\\"/><path fill=\\"#E5E5E5\\" d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2z\\"/><path fill=\\"#FFF\\" d=\\"M4.36 6.2h3.12c.204 0 .36-.152.36-.35a.349.349 0 0 0-.36-.35H4.36a.349.349 0 0 0-.36.35c0 .198.156.35.36.35zm0 2.333h7.44c.204 0 .36-.151.36-.35a.349.349 0 0 0-.36-.35H4.36a.349.349 0 0 0-.36.35c0 .199.156.35.36.35zm7.44 1.634H4.36a.349.349 0 0 0-.36.35c0 .198.156.35.36.35h7.44c.204 0 .36-.152.36-.35a.349.349 0 0 0-.36-.35z\\"/><path fill=\\"#CCC\\" d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75z\\"/></g></g>"},"37644":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path d=\\"M0 0h16v16H0z\\" fill-rule=\\"nonzero\\" fill-opacity=\\".01\\" fill=\\"#FFF\\"/><rect rx=\\"2\\" height=\\"16\\" width=\\"16\\" fill=\\"#EBECFF\\"/><path fill=\\"#6E74E0\\" d=\\"M12 4v2H9v7H7V6H4V4h8z\\"/></g></g>"},"38401":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path fill-opacity=\\".01\\" fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\"/><path data-follow-stroke=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"M31 36 19 24l12-12\\"/></g>"},"38898":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" fill-opacity=\\".01\\" fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\"/><path data-follow-stroke=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"M24 44a19.937 19.937 0 0 0 14.142-5.858A19.937 19.937 0 0 0 44 24a19.938 19.938 0 0 0-5.858-14.142A19.937 19.937 0 0 0 24 4 19.938 19.938 0 0 0 9.858 9.858 19.938 19.938 0 0 0 4 24a19.937 19.937 0 0 0 5.858 14.142A19.938 19.938 0 0 0 24 44z\\"/><path data-follow-stroke=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"M24 28.625v-4a6 6 0 1 0-6-6\\"/><path data-follow-fill=\\"currentColor\\" fill=\\"currentColor\\" d=\\"M24 37.625a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z\\" clip-rule=\\"evenodd\\" fill-rule=\\"evenodd\\"/></g>"},"39856":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path fill-opacity=\\".01\\" fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\"/><path data-follow-stroke=\\"currentColor\\" data-follow-fill=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" fill=\\"currentColor\\" d=\\"M24 44c11.046 0 20-8.954 20-20S35.046 4 24 4 4 12.954 4 24s8.954 20 20 20z\\"/><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"#FFF\\" d=\\"M29.657 18.343 18.343 29.657m0-11.314 11.314 11.314\\"/></g>"},"39927":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"nonzero\\" fill=\\"none\\"><path d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\"/><path fill=\\"#FF5562\\" d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2z\\"/><path fill=\\"#FFF\\" d=\\"m11.465 10.177-1.407-2.086a.224.224 0 0 0-.191-.096.254.254 0 0 0-.191.096L8.922 9.21 7.234 6.597a.224.224 0 0 0-.191-.097.254.254 0 0 0-.191.097l-2.318 3.58a.188.188 0 0 0 0 .215.21.21 0 0 0 .191.108h6.548a.254.254 0 0 0 .203-.108c.034-.075.034-.16-.011-.215zM9.5 6a.5.5 0 1 0 1 0 .5.5 0 0 0-1 0z\\"/><path fill=\\"#FFBBC0\\" d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75z\\"/></g></g>"},"43077":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path d=\\"M21 38c9.389 0 17-7.611 17-17S30.389 4 21 4 4 11.611 4 21s7.611 17 17 17z\\" stroke=\\"#666\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\" data-follow-stroke=\\"#666\\"/><path d=\\"M21 15v12m-6-6h12m6.222 12.222 8.485 8.485\\" stroke=\\"#666\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\" data-follow-stroke=\\"#666\\"/></g>"},"44439":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-stroke=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"m26.122 37.435 14.142-14.142c2.828-2.829 4.243-9.9-.707-14.85-4.95-4.95-12.02-3.535-14.85-.706L5.617 26.828c-1.414 1.415-3.536 6.364.707 10.607 4.242 4.243 9.192 2.121 10.607.707l18.384-18.385c1.414-1.414 2.122-4.95 0-7.07-2.121-2.122-5.657-1.415-7.07 0L14.807 26.12\\"/></g>"},"44440":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"#3693ff\\" d=\\"m26.122 37.435 14.142-14.142c2.828-2.829 4.243-9.9-.707-14.85-4.95-4.95-12.02-3.535-14.85-.706L5.617 26.828c-1.414 1.415-3.536 6.364.707 10.607 4.242 4.243 9.192 2.121 10.607.707l18.384-18.385c1.414-1.414 2.122-4.95 0-7.07-2.121-2.122-5.657-1.415-7.07 0L14.807 26.12\\"/></g>"},"44726":{"viewBox":"0 0 48 48","fill":"none","content":"<g><rect width=\\"48\\" height=\\"48\\" fill=\\"white\\" fill-opacity=\\"0.01\\"/><path d=\\"M6 24.0083V42H42V24\\" stroke=\\"#3693ff\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path d=\\"M33 23L24 32L15 23\\" stroke=\\"#3693ff\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path d=\\"M23.9917 6V32\\" stroke=\\"#3693ff\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"44727":{"viewBox":"0 0 48 48","fill":"none","content":"<g><rect width=\\"48\\" height=\\"48\\" fill=\\"white\\" fill-opacity=\\"0.01\\"/><mask id=\\"icon-306bf0d79ed4cfde\\" maskUnits=\\"userSpaceOnUse\\" x=\\"0\\" y=\\"0\\" width=\\"48\\" height=\\"48\\" style=\\"mask-type: alpha\\"><rect width=\\"48\\" height=\\"48\\" fill=\\"#3693ff\\"/></mask><g mask=\\"url(#icon-306bf0d79ed4cfde)\\"><path d=\\"M6 24.0083V42H42V24\\" stroke=\\"#3693ff\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path d=\\"M33 15L24 6L15 15\\" stroke=\\"#3693ff\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path d=\\"M23.9917 32V6\\" stroke=\\"#3693ff\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g></g>"},"44996":{"viewBox":"0 0 16 16","content":"<g><path d=\\"M8.2 14.8c3.7 0 6.7-3 6.7-6.7s-3.1-6.6-6.7-6.6-6.7 3-6.7 6.7 3 6.6 6.7 6.6z\\" fill-rule=\\"evenodd\\" clip-rule=\\"evenodd\\" fill=\\"#ed4014\\" stroke=\\"#ed4014\\"/><path fill=\\"none\\" stroke=\\"#fff\\" stroke-width=\\"1.333\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\" d=\\"M10.5 7.5 8.2 5.2 5.8 7.5M10.5 10.5 8.2 8.2l-2.4 2.3\\"/></g>"},"57905":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path fill-opacity=\\".01\\" fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\" data-follow-fill=\\"currentColor\\"/><path data-follow-stroke=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"M24 44a19.937 19.937 0 0 0 14.142-5.858A19.937 19.937 0 0 0 44 24a19.938 19.938 0 0 0-5.858-14.142A19.937 19.937 0 0 0 24 4 19.938 19.938 0 0 0 9.858 9.858 19.938 19.938 0 0 0 4 24a19.937 19.937 0 0 0 5.858 14.142A19.938 19.938 0 0 0 24 44z\\"/><path data-follow-fill=\\"currentColor\\" fill=\\"currentColor\\" d=\\"M24 37a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z\\" clip-rule=\\"evenodd\\" fill-rule=\\"evenodd\\"/><path data-follow-stroke=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"M24 12v16\\"/></g>"},"60372":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h16v16H0z\\"/><path fill=\\"#E5E5E5\\" d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2z\\"/><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M4 4h8v8H4z\\"/><path fill=\\"#999\\" d=\\"M9.06 6.094a1.333 1.333 0 0 1 1.983 1.778l-.097.108L8 10.926a1.833 1.833 0 0 1-2.705-2.47l.112-.123 2.475-2.475a.333.333 0 0 1 .52.412l-.048.06-2.475 2.475a1.167 1.167 0 0 0 1.548 1.74l.102-.09 2.946-2.947a.667.667 0 0 0-.86-1.013l-.083.07-2.946 2.947a.167.167 0 0 0 .192.267l.043-.031 2.475-2.475a.333.333 0 0 1 .52.41l-.048.061-2.475 2.475A.833.833 0 0 1 6.04 9.126l.074-.086 2.947-2.946z\\"/><path fill=\\"#CCC\\" d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75z\\"/></g></g>"},"60460":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M18 6H8a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2zm0 22H8a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V30a2 2 0 0 0-2-2zM40 6H30a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2zm0 22H30a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V30a2 2 0 0 0-2-2z\\" stroke=\\"#666\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\" data-follow-stroke=\\"#666\\"/></g>"},"60464":{"viewBox":"0 0 48 48","fill":"none","content":"<g><rect data-follow-stroke=\\"#666\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"#666\\" rx=\\"3\\" height=\\"36\\" width=\\"40\\" y=\\"6\\" x=\\"4\\"/><path data-follow-stroke=\\"#666\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"#666\\" d=\\"M4 14h40M20 24h16M20 32h16M12 24h2M12 32h2\\"/></g>"},"60811":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path data-follow-fill=\\"#FFF\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\" d=\\"M0 0h16v16H0z\\"/><path data-follow-fill=\\"#666\\" d=\\"M8.5 11.5v2h-7v-2h7zm6-4.5v2h-13V7h13zm0-4.5v2h-13v-2h13z\\" fill=\\"#666\\"/></g></g>"},"60900":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path d=\\"m13 30 12-12 12 12\\" stroke=\\"#666\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"bevel\\" data-follow-stroke=\\"#666\\"/></g>"},"60921":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-stroke=\\"#666\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"#666\\" d=\\"M22 42H6V26M26 6h16v16\\"/></g>"},"60922":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-stroke=\\"#666\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"#666\\" d=\\"M44 20H28V4M4 28h16v16\\"/></g>"},"60927":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path fill-opacity=\\".01\\" fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\"/><path data-follow-stroke=\\"#666\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"#666\\" d=\\"M24.008 12.1V36M12 24l12-12 12 12\\"/></g>"},"60928":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path d=\\"M24.008 35.9V12M36 24 24 36 12 24\\" stroke=\\"#666\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\" data-follow-stroke=\\"#666\\"/></g>"},"62283":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path fill-opacity=\\".01\\" fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\"/><path data-follow-stroke=\\"currentColor\\" data-follow-fill=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" fill=\\"currentColor\\" d=\\"M24 44a19.937 19.937 0 0 0 14.142-5.858A19.937 19.937 0 0 0 44 24a19.938 19.938 0 0 0-5.858-14.142A19.937 19.937 0 0 0 24 4 19.938 19.938 0 0 0 9.858 9.858 19.938 19.938 0 0 0 4 24a19.937 19.937 0 0 0 5.858 14.142A19.938 19.938 0 0 0 24 44z\\"/><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"#FFF\\" d=\\"M24 28.625v-4a6 6 0 1 0-6-6\\"/><path fill=\\"#FFF\\" d=\\"M24 37.625a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z\\" clip-rule=\\"evenodd\\" fill-rule=\\"evenodd\\"/></g>"},"64718":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"#666\\" d=\\"M24 44c11.046 0 20-8.954 20-20S35.046 4 24 4 4 12.954 4 24s8.954 20 20 20z\\" stroke=\\"#666\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"#666\\" d=\\"M29.657 18.343 18.343 29.657m0-11.314 11.314 11.314\\" stroke=\\"#666\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"72398":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path fill-opacity=\\".01\\" fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\" data-follow-fill=\\"#fff\\"/><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"#666\\" d=\\"M14 23.992h28M26 36 14 24l12-12M5 36V12\\" data-follow-stroke=\\"#666\\"/></g>"},"72400":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path fill-opacity=\\".01\\" fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\" data-follow-fill=\\"#fff\\"/><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"#666\\" d=\\"M34 24.008H6M22 12l12 12-12 12M42 12v24\\" data-follow-stroke=\\"#666\\"/></g>"},"76393":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path fill-opacity=\\".01\\" fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\"/><path stroke-linejoin=\\"round\\" stroke-width=\\"4\\" stroke=\\"#19BE6B\\" fill=\\"#19BE6B\\" d=\\"M24 44a19.937 19.937 0 0 0 14.142-5.858A19.937 19.937 0 0 0 44 24a19.938 19.938 0 0 0-5.858-14.142A19.937 19.937 0 0 0 24 4 19.938 19.938 0 0 0 9.858 9.858 19.938 19.938 0 0 0 4 24a19.937 19.937 0 0 0 5.858 14.142A19.938 19.938 0 0 0 24 44z\\"/><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"#FFF\\" d=\\"m16 24 6 6 12-12\\"/></g>"},"76394":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path fill-opacity=\\".01\\" fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\"/><path stroke-linejoin=\\"round\\" stroke-width=\\"4\\" stroke=\\"#ccc\\" fill=\\"#ccc\\" d=\\"M24 44c11.046 0 20-8.954 20-20S35.046 4 24 4 4 12.954 4 24s8.954 20 20 20z\\"/><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"#FFF\\" d=\\"M16 24h16\\"/></g>"},"77021":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-stroke=\\"#333\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"#333\\" d=\\"M23 8h20M14 41l-8-8m8-26v34m9-23h16M23 28h12M23 38h8\\"/></g>"},"77244":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"#333\\" d=\\"M4 7h40M4 23h11M4 39h11\\" stroke=\\"#333\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\"/><path data-follow-stroke=\\"#333\\" d=\\"M31.5 34a8.5 8.5 0 1 0 0-17 8.5 8.5 0 0 0 0 17z\\" stroke=\\"#333\\" stroke-width=\\"4\\"/><path data-follow-stroke=\\"#333\\" d=\\"m37 32 7 7.05\\" stroke=\\"#333\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\"/></g>"},"77269":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"#666\\" data-follow-fill=\\"#666\\" d=\\"M24 44a19.937 19.937 0 0 0 14.142-5.858A19.937 19.937 0 0 0 44 24a19.938 19.938 0 0 0-5.858-14.142A19.937 19.937 0 0 0 24 4 19.938 19.938 0 0 0 9.858 9.858 19.938 19.938 0 0 0 4 24a19.937 19.937 0 0 0 5.858 14.142A19.938 19.938 0 0 0 24 44z\\" fill=\\"#666\\" stroke=\\"#666\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/><path fill-rule=\\"evenodd\\" clip-rule=\\"evenodd\\" d=\\"M24 37a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z\\" fill=\\"#FFF\\"/><path d=\\"M24 12v16\\" stroke=\\"#FFF\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"77297":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h16v16H0z\\" data-follow-fill=\\"#FFF\\"/><path fill=\\"#666\\" d=\\"M8 15.333a7.31 7.31 0 0 0 5.185-2.148A7.311 7.311 0 0 0 15.333 8a7.31 7.31 0 0 0-2.148-5.185A7.311 7.311 0 0 0 8 .667a7.31 7.31 0 0 0-5.185 2.148A7.311 7.311 0 0 0 .667 8c0 1.97.782 3.82 2.148 5.185A7.311 7.311 0 0 0 8 15.333zm0-10a.833.833 0 1 1 0-1.666.833.833 0 0 1 0 1.666zm0 7.334A.667.667 0 0 1 7.333 12V6.667l.008-.099a.667.667 0 0 1 1.326.099V12l-.008.099a.667.667 0 0 1-.659.568z\\" data-follow-fill=\\"#666\\"/></g></g>"},"77464":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M24 44a19.937 19.937 0 0 0 14.142-5.858A19.937 19.937 0 0 0 44 24a19.938 19.938 0 0 0-5.858-14.142A19.937 19.937 0 0 0 24 4 19.938 19.938 0 0 0 9.858 9.858 19.938 19.938 0 0 0 4 24a19.937 19.937 0 0 0 5.858 14.142A19.938 19.938 0 0 0 24 44z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/><path data-follow-fill=\\"currentColor\\" fill-rule=\\"evenodd\\" clip-rule=\\"evenodd\\" d=\\"M24 37a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z\\" fill=\\"currentColor\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M24 12v16\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"80166":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path d=\\"M0 0h16v16H0z\\" fill-rule=\\"nonzero\\" fill-opacity=\\".01\\" fill=\\"#FFF\\"/><rect rx=\\"2\\" height=\\"16\\" width=\\"16\\" fill=\\"#E0EFFF\\"/><path stroke-width=\\"2\\" stroke=\\"#3693FF\\" d=\\"M12.5 7h-6v6h6z\\" data-follow-stroke=\\"#3693FF\\"/><path stroke-width=\\"2\\" stroke=\\"#3693FF\\" d=\\"M11 3.5H3v8\\" data-follow-stroke=\\"#3693FF\\"/></g></g>"},"86260":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-stroke=\\"currentColor\\" d=\\"M39 6H9a3 3 0 0 0-3 3v30a3 3 0 0 0 3 3h30a3 3 0 0 0 3-3V9a3 3 0 0 0-3-3z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M26 24H14m20-9H14m18 18H14\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"87901":{"viewBox":"0 0 48 48","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><circle fill=\\"#0CAAAB\\" cx=\\"24\\" cy=\\"24\\" r=\\"24\\"/><path fill=\\"#FFF\\" fill-rule=\\"nonzero\\" d=\\"M15 12h18a3 3 0 0 1 3 3v18a3 3 0 0 1-3 3H15a3 3 0 0 1-3-3V15a3 3 0 0 1 3-3zm3 7.5V21h7.5v-1.5H18zm0 4.5v1.5h12V24H18zm0 4.5V30h12v-1.5H18z\\"/></g></g>"},"87902":{"viewBox":"0 0 11 12","fill":"currentColor","content":"<g><path data-follow-fill=\\"currentColor\\" fill=\\"currentColor\\" d=\\"M6.871 12a.458.458 0 0 1-.457-.461V4.617c0-.114.042-.226.118-.31L9.514.925H1.477L4.464 4.31a.468.468 0 0 1 .115.308v4.165l.727.593a.467.467 0 0 1 .07.65.456.456 0 0 1-.644.07l-.897-.737a.462.462 0 0 1-.17-.36V4.791L.117.769A.465.465 0 0 1 .04.273.458.458 0 0 1 .458 0h10.085c.182 0 .344.107.418.275a.465.465 0 0 1-.079.497L7.328 4.793v6.746A.458.458 0 0 1 6.87 12z\\"/></g>"},"87903":{"viewBox":"0 0 48 48","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><circle fill=\\"#3693FF\\" cx=\\"24\\" cy=\\"24\\" r=\\"24\\"/><path fill=\\"#FFF\\" fill-rule=\\"nonzero\\" d=\\"M35.996 13.951c-.069 2.215-.55 4.344-1.354 6.407-.96 2.468-2.367 4.64-4.338 6.435a.547.547 0 0 0-.188.506c.068.664.122 1.33.191 1.993.16 1.548-.385 2.816-1.642 3.715-1.347.964-2.75 1.854-4.14 2.758-.876.569-1.953.052-2.05-.98a141.655 141.655 0 0 1-.284-3.563c-.042-.595-.026-.6-.605-.676-1.54-.202-2.744-.928-3.57-2.245-.426-.678-.637-1.427-.711-2.215-.022-.236-.118-.296-.342-.309a192.34 192.34 0 0 1-3.734-.235c-1.035-.077-1.559-1.161-1.004-2.065.389-.636.803-1.257 1.206-1.885.433-.676.863-1.354 1.297-2.03.795-1.235 1.94-1.903 3.407-1.915.84-.006 1.68.14 2.52.23.158.017.271-.004.38-.126 1.95-2.164 4.36-3.624 7.09-4.6a20.164 20.164 0 0 1 4.76-1.08c.821-.085 1.648-.116 2.469.035.447.082.47.1.538.534.07.434.124.87.104 1.311zm-3.89 5.464c.023-1.893-1.554-3.52-3.43-3.55-1.946-.033-3.633 1.374-3.679 3.57-.039 1.832 1.631 3.49 3.495 3.504a3.565 3.565 0 0 0 3.613-3.524zM15.474 27.41c.368.005.573.167.705.54.518 1.466 1.46 2.579 2.827 3.333.301.166.62.3.948.412.59.2.725.771.287 1.21-.65.652-1.305 1.295-1.953 1.946-.215.215-.45.317-.752.205-.307-.113-.454-.339-.47-.654-.01-.2-.005-.4-.01-.6-.008-.368-.012-.371-.353-.26-.729.24-1.456.483-2.185.723-.215.07-.43.1-.64-.018-.308-.174-.425-.484-.3-.865.241-.744.495-1.484.743-2.226.107-.322.1-.329-.25-.334-.21-.003-.422 0-.633-.01-.307-.015-.526-.162-.64-.451-.11-.281-.04-.527.168-.734.677-.676 1.357-1.35 2.036-2.024.135-.134.296-.21.472-.193z\\"/></g></g>"},"87904":{"viewBox":"0 0 48 48","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><circle fill=\\"#F90\\" cx=\\"24\\" cy=\\"24\\" r=\\"24\\"/><path fill=\\"#FFF\\" fill-rule=\\"nonzero\\" d=\\"M34.682 21.295h-1.474V16.9a1.009 1.009 0 0 0-1.011-1.001H26.78v-1.744a3.138 3.138 0 0 0-.948-2.254 3.172 3.172 0 0 0-2.284-.9 3.26 3.26 0 0 0-3.12 3.3v1.598h-5.417c-.556 0-1.009.447-1.011 1.001v3.38a1.006 1.006 0 0 0 1.011 1.015h.566a3.263 3.263 0 0 1 3.317 3.1 3.137 3.137 0 0 1-.91 2.269 3.171 3.171 0 0 1-2.27.936h-.703c-.558 0-1.011.45-1.011 1.006v5.388c0 .556.453 1.006 1.011 1.006h4.406a1.01 1.01 0 0 0 .716-.293.999.999 0 0 0 .295-.713v-.499a3.26 3.26 0 0 1 3.12-3.3 3.172 3.172 0 0 1 2.284.9c.609.595.95 1.408.948 2.255v.644a.999.999 0 0 0 .293.711c.19.189.446.295.714.295h4.41c.558 0 1.011-.45 1.011-1.006V27.6h1.616a3.171 3.171 0 0 0 2.268-.94 3.137 3.137 0 0 0 .907-2.27 3.263 3.263 0 0 0-3.317-3.095z\\"/></g></g>"},"87905":{"viewBox":"0 0 14 14","fill":"currentColor","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h14v14H0z\\"/><path fill=\\"#666\\" d=\\"M7.5 0a6.48 6.48 0 0 1 4.596 1.904A6.48 6.48 0 0 1 14 6.5a6.48 6.48 0 0 1-1.904 4.596A6.48 6.48 0 0 1 7.5 13a6.48 6.48 0 0 1-4.596-1.904A6.48 6.48 0 0 1 1 6.5a6.48 6.48 0 0 1 1.904-4.596A6.48 6.48 0 0 1 7.5 0zm0 1.182c-1.43 0-2.77.566-3.76 1.557A5.299 5.299 0 0 0 2.181 6.5c0 1.43.566 2.77 1.557 3.76A5.299 5.299 0 0 0 7.5 11.819c1.43 0 2.77-.566 3.76-1.557A5.299 5.299 0 0 0 12.819 6.5c0-1.43-.566-2.77-1.557-3.76A5.299 5.299 0 0 0 7.5 1.181zm-.886 8.863a.59.59 0 0 1-.088-1.175l.088-.006.442-.001V5.909l-.087-.006a.591.591 0 0 1-.497-.497l-.006-.088a.59.59 0 0 1 .503-.584l.088-.007h.59c.297 0 .543.219.585.504l.007.087-.001 3.545h.444a.59.59 0 0 1 .087 1.176l-.087.006H6.614zM7.5 2.66a.739.739 0 1 1 0 1.477.739.739 0 0 1 0-1.477z\\"/></g></g>"},"90491":{"viewBox":"0 0 14 11","fill":"currentColor","content":"<g><path data-follow-fill=\\"currentColor\\" fill=\\"currentColor\\" d=\\"M5.706.367h7.746c.3 0 .548.25.548.55 0 .307-.248.55-.548.55H5.706a.553.553 0 0 1-.548-.55c0-.3.247-.55.548-.55zm-.548 9.716c0-.307.247-.55.548-.55h7.746c.3 0 .548.251.548.55 0 .3-.248.55-.548.55H5.697c-.3 0-.54-.25-.54-.55zm0-4.766c0-.308.247-.55.548-.55h7.746c.3 0 .548.25.548.55 0 .307-.248.55-.548.55H5.697a.54.54 0 0 1-.54-.55zM4.18 8.435c.107 0 .178.051.214.154.044.102.027.195-.044.264l-1.984 2.062a.201.201 0 0 1-.16.085.18.18 0 0 1-.16-.085L.063 8.853C0 8.784-.017 8.699.018 8.589a.217.217 0 0 1 .223-.154h1.405V2.556H.249c-.098.009-.186-.06-.222-.153C-.017 2.3 0 2.215.07 2.147L2.055.085A.201.201 0 0 1 2.215 0a.19.19 0 0 1 .16.085l1.983 2.062c.063.068.08.153.045.256-.036.102-.125.162-.223.153H2.767v5.87H4.18v.01z\\"/></g>"},"94434":{"viewBox":"0 0 12 15","fill":"currentColor","content":"<g><path data-follow-fill=\\"currentColor\\" fill=\\"currentColor\\" d=\\"M4.444 15S-2.208 13.537.765 6.275c0 0 .675.807.582 1.195 0 0 .53-1.833 1.671-2.928C4 3.6 4.995.956 4.076 0c0 0 4.552.956 5.059 5.737 0 0 .582-1.523 1.777-1.674 0 0-.367.837 0 2.093 0 0 3.77 6.453-2.727 8.635 0 0 1.948-2.212-2.183-6.007 0 0-.974 2.033-1.556 2.749-.002.002-1.627 1.823-.002 3.467z\\"/></g>"},"94997":{"viewBox":"0 0 14 14","fill":"currentColor","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path data-follow-fill=\\"currentColor\\" d=\\"M6.583 13.083a6.48 6.48 0 0 0 4.596-1.904 6.48 6.48 0 0 0 1.904-4.596 6.48 6.48 0 0 0-1.904-4.596A6.48 6.48 0 0 0 6.583.083a6.48 6.48 0 0 0-4.596 1.904A6.48 6.48 0 0 0 .083 6.583a6.48 6.48 0 0 0 1.904 4.596 6.48 6.48 0 0 0 4.596 1.904z\\" fill=\\"currentColor\\" fill-rule=\\"nonzero\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"m3.983 6.583 1.95 1.95 3.9-3.9\\" stroke=\\"currentColor\\" stroke-width=\\"1.333\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g></g>"},"94998":{"viewBox":"0 0 13 13","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><circle fill=\\"#3693FF\\" cx=\\"6.5\\" cy=\\"6.5\\" r=\\"6.5\\"/><path d=\\"m9.906 6.792-.052.062-3 3a.5.5 0 0 1-.76-.646l.052-.062L8.29 7.002H3.5a.5.5 0 0 1-.074-.995l.074-.005h4.796l-2.15-2.148a.5.5 0 0 1-.052-.646l.052-.062a.5.5 0 0 1 .646-.052l.062.052 3 3a.5.5 0 0 1 .052.646z\\" fill=\\"#FFF\\"/></g></g>"},"94999":{"viewBox":"0 0 13 13","fill":"currentColor","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><circle data-follow-fill=\\"currentColor\\" fill=\\"currentColor\\" cx=\\"6.5\\" cy=\\"6.5\\" r=\\"6.5\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M3.5 6.5h6\\" stroke=\\"currentColor\\" stroke-linecap=\\"round\\"/></g></g>"},"95027":{"viewBox":"0 0 18 18","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><rect fill=\\"#ED4014\\" width=\\"18\\" height=\\"18\\" rx=\\"4\\"/><text font-family=\\"PingFangSC-Regular, PingFang SC\\" font-size=\\"12\\" fill=\\"#FFF\\"><tspan x=\\"3\\" y=\\"13\\">热</tspan></text></g></g>"},"95143":{"viewBox":"0 0 30 29","fill":"currentColor","content":"<g><g transform=\\"translate(.076 .029)\\" fill=\\"none\\"><rect data-follow-fill=\\"currentColor\\" rx=\\"13.937\\" height=\\"27.873\\" width=\\"28.445\\" opacity=\\".296\\" fill=\\"currentColor\\"/><path fill=\\"#A6A6A6\\" d=\\"M11.711 19.072a.718.718 0 0 1-.502-.205.683.683 0 0 1 0-.983l4.435-4.349-4.435-4.345a.685.685 0 0 1 0-.985.72.72 0 0 1 1.005 0l4.939 4.838a.688.688 0 0 1 0 .986l-4.94 4.838a.718.718 0 0 1-.502.205z\\"/></g></g>"},"95144":{"viewBox":"0 0 30 29","content":"<g><g fill-rule=\\"nonzero\\" transform=\\"rotate(-180 14.538 14.015)\\" fill=\\"none\\"><rect rx=\\"13.937\\" height=\\"27.873\\" width=\\"28.445\\" opacity=\\".296\\" fill=\\"#FFF\\"/><path fill=\\"#A6A6A6\\" d=\\"M11.711 20.072a.718.718 0 0 1-.502-.205.683.683 0 0 1 0-.983l4.435-4.349-4.435-4.345a.685.685 0 0 1 0-.985.72.72 0 0 1 1.005 0l4.939 4.838a.688.688 0 0 1 0 .986l-4.94 4.838a.718.718 0 0 1-.502.205z\\"/></g></g>"},"95579":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><circle r=\\"8\\" cy=\\"8\\" cx=\\"8\\" fill=\\"#ED4014\\" data-follow-fill=\\"#ED4014\\"/><path stroke-linecap=\\"round\\" stroke=\\"#FFF\\" d=\\"m5.5 5.5 5 5M5.5 10.5l5-5\\" data-follow-stroke=\\"#FFF\\"/></g></g>"},"98755":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><g><path d=\\"M0 0h16v16H0z\\" fill-rule=\\"nonzero\\" fill-opacity=\\".01\\" fill=\\"#FFF\\"/><rect rx=\\"2\\" height=\\"16\\" width=\\"16\\" fill=\\"#FFDCD3\\"/></g><path d=\\"M8.985 11 6.601 7.795 5.477 8.884H2V6.973h2.775L6.804 5l2.415 3.244 1.38-1.271H14v1.91h-2.726z\\" fill-rule=\\"nonzero\\" fill=\\"#ED4014\\"/></g></g>"},"98763":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><rect rx=\\"2\\" height=\\"16\\" width=\\"16\\" fill=\\"#C0F7DA\\"/><path fill=\\"#19BE6B\\" d=\\"m2 10 .593 1.001c1.7 2.868 5.463 3.85 8.407 2.195l-.802-1.355a4.65 4.65 0 0 1-4.835-.174l1.18-1.631L2 10zM10.827 3 10 4.327c1.559.833 2.465 2.418 2.332 4.08l-2.102-.179L12.538 12l.611-.979c1.752-2.808.712-6.4-2.322-8.021zM9 2H7.869C4.628 2 2 4.686 2 8h1.531c0-1.759 1.001-3.278 2.452-3.995l.819 1.813L9 2z\\"/></g></g>"},"100734":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path d=\\"M0 0h16v16H0z\\" fill-rule=\\"nonzero\\" fill-opacity=\\".01\\" fill=\\"#FFF\\"/><rect rx=\\"2\\" height=\\"16\\" width=\\"16\\" fill=\\"#FCD8C4\\"/><path fill=\\"#ED4014\\" d=\\"M5.928 3.525h3.7a.2.2 0 0 1 .189.267L8.98 6.17a.2.2 0 0 0 .189.266h2.335a.2.2 0 0 1 .165.314l-4.924 7.154a.2.2 0 0 1-.361-.149l.794-4.424a.2.2 0 0 0-.197-.235H4.373a.2.2 0 0 1-.192-.258l1.555-5.171a.2.2 0 0 1 .192-.143z\\"/></g></g>"},"100736":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path fill-opacity=\\".01\\" fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\" data-follow-fill=\\"#fff\\"/><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"#333\\" d=\\"M11.678 20.271C7.275 21.318 4 25.277 4 30c0 5.523 4.477 10 10 10 .947 0 1.864-.132 2.733-.378M36.055 20.271c4.403 1.047 7.677 5.006 7.677 9.729 0 5.523-4.477 10-10 10v0c-.947 0-1.864-.132-2.732-.378M36 20c0-6.627-5.373-12-12-12s-12 5.373-12 12M17.065 27.881 24 20.924 31.132 28M24 38V24.462\\" data-follow-stroke=\\"#333\\"/></g>"},"100749":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path d=\\"M0 0h16v16H0z\\" fill-rule=\\"nonzero\\" fill-opacity=\\".01\\" fill=\\"#FFF\\"/><rect rx=\\"2\\" height=\\"16\\" width=\\"16\\" fill=\\"#EBECFF\\"/><path fill=\\"#6E74E0\\" d=\\"M10.191 6.63a.324.324 0 0 1 .459-.01l3.297 3.146.01.01a.324.324 0 0 1-.01.458L10.65 13.38a.324.324 0 0 1-.548-.234v-2.03H7.358a.324.324 0 0 1-.324-.325V9.21c0-.179.145-.324.324-.324h2.744v-2.03c0-.084.032-.164.09-.224zm-4.815-4c.057.06.09.14.09.224v2.031H8.21c.179 0 .324.145.324.324v1.582a.324.324 0 0 1-.324.324H5.466v2.03a.324.324 0 0 1-.548.235L1.62 6.234a.324.324 0 0 1-.01-.458l.01-.01L4.918 2.62a.324.324 0 0 1 .458.01z\\"/></g></g>"},"103160":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\" fill=\\"currentColor\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M39 4H11a2 2 0 0 0-2 2v36a2 2 0 0 0 2 2h28a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zM17 30h14m-14 6h7\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M17 12h14v10H17z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"103161":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-stroke=\\"currentColor\\" d=\\"M8 44V4h23l9 10.5V44H8z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M15 28h6v7h-6zm-1 7h20M21 23h6v12h-6zm6-5h6v17h-6z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"103199":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"M48 0H0v48h48V0z\\" fill=\\"currentColor\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M43 5 29.7 43l-7.6-17.1L5 18.3 43 5z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M43 5 22.1 25.9\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"108308":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\" fill=\\"currentColor\\" fill-opacity=\\".01\\"/><circle data-follow-stroke=\\"currentColor\\" cx=\\"24\\" cy=\\"24\\" r=\\"20\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M24 4a20 20 0 0 1 14.58 33.69L24 24V4z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"108309":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\" fill=\\"currentColor\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M5 19h38v21a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V19zM5 9a2 2 0 0 1 2-2h34a2 2 0 0 1 2 2v10H5V9z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M16 4v8m16-8v8m-4 22h6m-20 0h6m8-8h6m-20 0h6\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"116059":{"viewBox":"0 0 29 29","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\" transform=\\"translate(.5 .5)\\"><circle fill=\\"#70B2FF\\" cx=\\"14\\" cy=\\"14\\" r=\\"14\\"/><g fill=\\"#FFF\\"><path d=\\"M6 6h16v16H6z\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\"/><path d=\\"m9.526 20.972-.05.013a.668.668 0 0 1-.04.007L9.332 21l-.102-.008a.668.668 0 0 1-.286-.117l-.027-.02a.67.67 0 0 1-.042-.037l-.014-.013-2-2a.667.667 0 0 1 .86-1.013l.083.07.862.861V13c0-.335.246-.612.568-.66l.098-.007H16a.667.667 0 0 1 .099 1.326l-.099.008-6.001-.001v5.056l.863-.86a.667.667 0 0 1 1.013.86l-.07.083-2 2-.014.013a.67.67 0 0 1-.046.04l.06-.053a.67.67 0 0 1-.27.164l-.01.003zm9.243-13.964.055.01a.662.662 0 0 1 .231.107l.02.015a.67.67 0 0 1 .05.042l.013.013 2 2a.667.667 0 0 1-.86 1.013l-.083-.07-.862-.863v7.058a.667.667 0 0 1-.568.66l-.098.007H12a.667.667 0 0 1-.099-1.326l.099-.007 5.999-.001v-6.39l-.86.862a.667.667 0 0 1-.861.07l-.083-.07a.667.667 0 0 1-.07-.86l.07-.083 2-2 .013-.013a.67.67 0 0 1 .05-.042l-.063.055a.67.67 0 0 1 .574-.187z\\"/></g></g></g>"},"116060":{"viewBox":"0 0 29 29","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\" transform=\\"translate(.5 .5)\\"><circle fill=\\"#FCBD4B\\" cx=\\"14\\" cy=\\"14\\" r=\\"14\\"/><g fill=\\"#FFF\\"><path d=\\"M6 6h16v16H6z\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\"/><path d=\\"M8 20.333a.667.667 0 0 1-.099-1.326L8 19h2v-4.667a4 4 0 0 1 3.8-3.995l.2-.005a4 4 0 0 1 4 4V19h2.333a.667.667 0 0 1 .099 1.326l-.099.007H8zm6-8.666a2.667 2.667 0 0 0-2.667 2.666V19h5.333v-4.666a2.667 2.667 0 0 0-2.497-2.661zm6.73.98a.667.667 0 0 1-.445.748l-.096.024-.985.174a.667.667 0 0 1-.327-1.29l.095-.023.985-.174a.667.667 0 0 1 .773.54zm-12.786-.551.099.01.985.174a.667.667 0 0 1-.134 1.323l-.098-.01-.985-.174a.667.667 0 0 1 .133-1.323zm10.448-3.497a.667.667 0 0 1 .145.85l-.062.089-.643.766a.667.667 0 0 1-1.084-.769l.062-.088.643-.766a.667.667 0 0 1 .94-.082zm-7.921.005.076.077.643.766a.667.667 0 0 1-.946.934l-.076-.077-.643-.766a.667.667 0 0 1 .946-.934zM14 7c.335 0 .612.247.66.568l.007.099v1a.667.667 0 0 1-1.326.098l-.008-.098v-1c0-.369.299-.667.667-.667z\\"/></g></g></g>"},"116891":{"viewBox":"0 0 24 24","fill":"currentColor","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h24v24H0z\\"/><path data-follow-fill=\\"currentColor\\" fill=\\"currentColor\\" d=\\"M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z\\"/><path data-follow-stroke=\\"currentColor\\" stroke-width=\\"2\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke=\\"currentColor\\" d=\\"M16.172 11.929h-8m4-4v8\\"/></g></g>"},"116928":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path d=\\"M24 44c11.046 0 20-8.954 20-20S35.046 4 24 4 4 12.954 4 24s8.954 20 20 20z\\" fill=\\"#2FDA84\\" stroke=\\"#2FDA84\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/><path d=\\"M31 31s-2 4-7 4-7-4-7-4m14-13v4m-14-4v4\\" stroke=\\"#FFF\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"116931":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path d=\\"M24 44c11.046 0 20-8.954 20-20S35.046 4 24 4 4 12.954 4 24s8.954 20 20 20z\\" fill=\\"#ED4014\\" stroke=\\"#ED4014\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/><path d=\\"M31 18v1m-14-1v1m14 12s-2-4-7-4-7 4-7 4\\" stroke=\\"#FFF\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"116936":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path d=\\"M24 44c11.046 0 20-8.954 20-20S35.046 4 24 4 4 12.954 4 24s8.954 20 20 20z\\" fill=\\"#F90\\" stroke=\\"#F90\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/><path d=\\"M31 18v1m-14-1v1m0 12h14\\" stroke=\\"#FFF\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"120047":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><rect data-follow-fill=\\"#D8D8D8\\" fill=\\"#D8D8D8\\" width=\\"16\\" height=\\"16\\" rx=\\"1.829\\"/><g data-follow-stroke=\\"#4A4A4A\\" stroke=\\"#4A4A4A\\" stroke-linejoin=\\"round\\" stroke-width=\\".8\\"><path d=\\"m11.8 5.8-4-2-4 2v4l4 2 4-2z\\"/><path d=\\"m3.8 5.8 4 2m4-2-4 2m2-3-4 2\\" stroke-linecap=\\"round\\"/></g><path data-follow-stroke=\\"#4A4A4A\\" d=\\"M7.8 11.8v-4\\" stroke=\\"#4A4A4A\\" stroke-width=\\".8\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g></g>"},"120048":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><rect fill=\\"#EBECFF\\" width=\\"16\\" height=\\"16\\" rx=\\"2\\"/><path data-follow-stroke=\\"#6E74E0\\" d=\\"M7.5 9.5h-3v3h3zm0-5h-3v3h3zm5 5h-3v3h3z\\" stroke=\\"#6E74E0\\"/><path d=\\"M11.25 3.482 8.775 5.957l2.475 2.475 2.475-2.475z\\" fill=\\"#6E74E0\\"/></g></g>"},"125790":{"viewBox":"0 0 24 24","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path d=\\"M0 0h24v24H0z\\" fill-rule=\\"nonzero\\" fill-opacity=\\".01\\" fill=\\"#FFF\\"/><rect rx=\\"3\\" height=\\"24\\" width=\\"24\\" fill=\\"#EBECFF\\"/><path fill=\\"#6E74E0\\" d=\\"M19.5 3.45v18l-7.484-4.5-7.516 4.5v-18h15zm-3 3h-9v9.707l4.52-2.706 4.48 2.694V6.45z\\"/></g></g>"},"133540":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\" fill=\\"currentColor\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M40.518 34.316A9.21 9.21 0 0 0 44 24c-1.213-3.83-4.93-5.929-8.947-5.925h-2.321a14.737 14.737 0 1 0-25.31 13.428M24.009 41 24 23m6.364 11.636L24 41l-6.364-6.364\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"133571":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\" fill=\\"currentColor\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M43 11 16.875 37 5 25.182\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"135944":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\" fill=\\"currentColor\\" fill-opacity=\\".01\\"/><path d=\\"M14 29h28v12H14V29zm0-22h28v12H14V7z\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M14 13v6h28V7H14v6zm0 0H6v22h8m0 0v6h28V29H14v6z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M14 13H6v22h8m0-6h28v12H14V29zm0-22h28v12H14V7z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"137895":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\" fill=\\"currentColor\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M34 36 22 24l12-12m-20 0v24\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"137896":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\" fill=\\"currentColor\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"m14 12 12 12-12 12m20-24v24\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"139867":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\" fill=\\"currentColor\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M14 23.992h28M26 36 14 24l12-12M5 36V12\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"139868":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" fill-opacity=\\".01\\" fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\"/><path data-follow-stroke=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"M34 24.008H6M22 12l12 12-12 12m20-24v24\\"/></g>"},"141135":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path d=\\"M0 0h16v16H0z\\" fill-rule=\\"nonzero\\" fill-opacity=\\".01\\" fill=\\"#FFF\\"/><rect rx=\\"2\\" height=\\"16\\" width=\\"16\\" fill=\\"#E0EFFF\\"/><path fill-rule=\\"nonzero\\" fill=\\"#3693FF\\" d=\\"M7.5 1.6v6h-2v3h3v-2h6v6h-6v-2h-5v-5h-2v-6h6zm5 9h-2v2h2v-2zm-7-7h-2v2h2v-2z\\"/></g></g>"},"141176":{"viewBox":"0 0 26 26","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><circle fill=\\"#EEE\\" cx=\\"13\\" cy=\\"13\\" r=\\"13\\"/><path fill=\\"#666\\" d=\\"M19 6c.92 0 1.667.746 1.667 1.667v10c0 .92-.747 1.666-1.667 1.666H7.667c-.92 0-1.667-.746-1.667-1.666v-10C6 6.747 6.746 6 7.667 6zm.333 3.999h-12v7.668c0 .16.115.295.266.326l.068.007H19c.184 0 .333-.15.333-.333V9.999zm-2 4.668a.667.667 0 0 1 .099 1.326l-.099.007H12a.667.667 0 0 1-.099-1.326l.099-.007h5.333zm-7.333 0a.667.667 0 0 1 .099 1.326L10 16h-.667a.667.667 0 0 1-.098-1.326l.098-.007H10zM17.333 12a.667.667 0 0 1 .099 1.326l-.099.007H12a.667.667 0 0 1-.099-1.326L12 12h5.333zM10 12a.667.667 0 0 1 .099 1.326l-.099.007h-.667a.667.667 0 0 1-.098-1.326L9.333 12H10zm9-4.667H7.667a.333.333 0 0 0-.334.334v.999h12v-1a.333.333 0 0 0-.266-.326L19 7.333z\\"/></g></g>"},"141177":{"viewBox":"0 0 26 26","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><circle fill=\\"#EEE\\" cx=\\"13\\" cy=\\"13\\" r=\\"13\\"/><path d=\\"M20 7c.368 0 .667.298.667.667v10a.667.667 0 0 1-.667.666h-6.843L9.965 19.93a.667.667 0 0 1-.958-.5L9 19.333v-1H6.666a.667.667 0 0 1-.66-.568L6 17.667v-10C6 7.298 6.298 7 6.667 7zm-.668 1.333h-12V17h2.335a.67.67 0 0 1 .66.568l.006.099v.587l2.369-1.184a.667.667 0 0 1 .195-.062L13 17h6.332V8.333zM10 11.5c.335 0 .612.247.66.568l.007.099v1a.667.667 0 0 1-1.326.098l-.008-.098v-1c0-.369.299-.667.667-.667zm3.333 0c.335 0 .612.247.66.568l.007.099v1a.667.667 0 0 1-1.326.098l-.007-.098v-1c0-.369.298-.667.666-.667zm3.334 0a.67.67 0 0 1 .66.568l.006.099v1a.667.667 0 0 1-1.326.098L16 13.167v-1c0-.369.298-.667.667-.667z\\" fill=\\"#666\\"/></g></g>"},"141178":{"viewBox":"0 0 15 16","fill":"currentColor","content":"<g><g data-follow-stroke=\\"currentColor\\" fill=\\"none\\" fill-rule=\\"evenodd\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\" stroke=\\"currentColor\\" stroke-width=\\"1.333\\" transform=\\"translate(1 1.333)\\"><circle cx=\\"6.667\\" cy=\\"6.667\\" r=\\"6.667\\"/><path d=\\"M6.667 0a6.667 6.667 0 0 1 6.666 6.667H6.667V0z\\"/></g></g>"},"141179":{"viewBox":"0 0 18 15","fill":"currentColor","content":"<g><g data-follow-stroke=\\"currentColor\\" fill=\\"none\\" fill-rule=\\"evenodd\\" stroke-linejoin=\\"round\\" stroke=\\"currentColor\\" stroke-width=\\"1.641\\" transform=\\"translate(1 1)\\"><path d=\\"M.82 0h13.95a.82.82 0 0 1 .82.82v11.488a.82.82 0 0 1-.82.82H.82a.82.82 0 0 1-.82-.82V.82A.82.82 0 0 1 .82 0z\\" stroke-linecap=\\"round\\"/><circle stroke-linecap=\\"round\\" cx=\\"3.897\\" cy=\\"3.487\\" r=\\"1\\"/><path d=\\"m4.103 6.564 2.05 1.641 2.462-2.872 6.975 5.334v1.64a.82.82 0 0 1-.82.821H.82a.82.82 0 0 1-.82-.82v-1.641l4.103-4.103z\\"/></g></g>"},"141180":{"viewBox":"0 0 16 16","fill":"currentColor","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"currentColor\\" fill-rule=\\"nonzero\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M1.94 2.242v2.425h2.424\\" stroke=\\"currentColor\\" stroke-width=\\"1.333\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M1.333 8A6.667 6.667 0 0 0 8 14.667h0A6.667 6.667 0 1 0 2.226 4.666\\" stroke=\\"currentColor\\" stroke-width=\\"1.333\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M8.002 4v4.003l2.826 2.826\\" stroke=\\"currentColor\\" stroke-width=\\"1.333\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g></g>"},"141181":{"viewBox":"0 0 24 24","fill":"currentColor","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><circle fill=\\"#F90\\" cx=\\"12\\" cy=\\"12\\" r=\\"12\\"/><g transform=\\"translate(4 3)\\"><path d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><circle data-follow-stroke=\\"currentColor\\" stroke=\\"currentColor\\" stroke-width=\\"1.333\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\" cx=\\"4.667\\" cy=\\"9.667\\" r=\\"1.667\\"/><circle data-follow-stroke=\\"currentColor\\" stroke=\\"currentColor\\" stroke-width=\\"1.333\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\" cx=\\"11.333\\" cy=\\"9.667\\" r=\\"1.667\\"/><circle data-follow-stroke=\\"currentColor\\" stroke=\\"currentColor\\" stroke-width=\\"1.333\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\" cx=\\"8\\" cy=\\"3\\" r=\\"1.667\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M8 14.667a3.333 3.333 0 0 0-6.667 0m13.334 0a3.333 3.333 0 0 0-6.667 0M11.333 8a3.333 3.333 0 0 0-6.666 0\\" stroke=\\"currentColor\\" stroke-width=\\"1.333\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g></g></g>"},"141182":{"viewBox":"0 0 17 20","fill":"currentColor","content":"<g><g data-follow-stroke=\\"currentColor\\" fill=\\"none\\" fill-rule=\\"evenodd\\" stroke-linejoin=\\"round\\" stroke=\\"currentColor\\" stroke-width=\\"1.481\\" transform=\\"translate(1 1)\\"><rect x=\\".444\\" y=\\"7.407\\" width=\\"14.815\\" height=\\"10.37\\" rx=\\"1.481\\"/><path d=\\"M4.148 7.407V3.704C4.148 1.43 5.806 0 7.852 0c1.555 0 2.886.827 3.435 2.222m-3.435 9.63v1.481\\" stroke-linecap=\\"round\\"/></g></g>"},"141183":{"viewBox":"0 0 16 16","fill":"currentColor","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"currentColor\\" fill-rule=\\"nonzero\\"/><rect data-follow-stroke=\\"currentColor\\" stroke=\\"currentColor\\" stroke-width=\\"1.333\\" stroke-linejoin=\\"round\\" x=\\"2\\" y=\\"7.333\\" width=\\"12\\" height=\\"7.333\\" rx=\\".667\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M4.667 7.333V4.667a3.333 3.333 0 0 1 6.666 0v2.666M8 10v2\\" stroke=\\"currentColor\\" stroke-width=\\"1.333\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g></g>"},"141184":{"viewBox":"0 0 17 17","fill":"currentColor","content":"<g><g data-follow-stroke=\\"currentColor\\" fill=\\"none\\" fill-rule=\\"evenodd\\" stroke-linejoin=\\"round\\" stroke=\\"currentColor\\" stroke-width=\\"1.524\\"><path d=\\"M8.619 16.238A7.619 7.619 0 1 0 8.619 1a7.619 7.619 0 0 0 0 15.238z\\"/><path d=\\"M11.286 6.333v.381m-5.334-.381v.381m5.334 4.572s-.762 1.524-2.667 1.524c-1.905 0-2.667-1.524-2.667-1.524\\" stroke-linecap=\\"round\\"/></g></g>"},"141185":{"viewBox":"0 0 14 14","fill":"currentColor","content":"<g><path d=\\"M8.333 1H13v4.667m0 3.158V12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h3m2.6 5.4 5.1-5.1\\" data-follow-stroke=\\"currentColor\\" fill=\\"none\\" fill-rule=\\"evenodd\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\" stroke=\\"currentColor\\" stroke-width=\\"1.333\\"/></g>"},"141253":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h48v48H0z\\" fill=\\"currentColor\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M6 6v36h36M14 30v4m8-12v12m8-28v28m8-20v20\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"141407":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\" d=\\"M0 0h16v16H0z\\"/><path d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2z\\" fill=\\"#B1B6F7\\"/><path d=\\"M4.36 6.2h3.12c.204 0 .36-.152.36-.35a.349.349 0 0 0-.36-.35H4.36a.349.349 0 0 0-.36.35c0 .198.156.35.36.35zm0 2.333h7.44c.204 0 .36-.151.36-.35a.349.349 0 0 0-.36-.35H4.36a.349.349 0 0 0-.36.35c0 .199.156.35.36.35zm7.44 1.634H4.36a.349.349 0 0 0-.36.35c0 .198.156.35.36.35h7.44c.204 0 .36-.152.36-.35a.349.349 0 0 0-.36-.35z\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75z\\" fill=\\"#EBECFF\\"/></g></g>"},"141408":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\" d=\\"M0 0h16v16H0z\\"/><path d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2z\\" fill=\\"#FFB452\\"/><path d=\\"M7.043 6.5c.079 0 .146.032.191.097L8.922 9.21l.754-1.119a.254.254 0 0 1 .191-.096c.079 0 .146.032.191.096l1.407 2.086c.045.054.045.14.01.215a.254.254 0 0 1-.202.108H4.725a.21.21 0 0 1-.191-.108.188.188 0 0 1 0-.215l2.318-3.58a.254.254 0 0 1 .19-.097zm2.707-.933a.5.5 0 1 1 .5.866.5.5 0 0 1-.5-.866z\\" fill=\\"#FFF\\"/><path d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75z\\" fill=\\"#FFEBCC\\"/></g></g>"},"141409":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\" d=\\"M0 0h16v16H0z\\"/><path d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2z\\" fill=\\"#70B2FF\\"/><path d=\\"M4.5 6.5h.972l.972 3.558h.012L7.524 6.5h.936l1.08 3.558.984-3.558h.936l-1.44 4.585h-.972L7.98 7.562h-.012l-1.08 3.511h-.972z\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75z\\" fill=\\"#E0EFFF\\"/></g></g>"},"141410":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\" d=\\"M0 0h16v16H0z\\"/><path d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2z\\" fill=\\"#FA6C42\\"/><path d=\\"M10.37 12.278c-.756 0-1.428-1.26-1.788-2.077a13.29 13.29 0 0 0-1.896-.618c-.564.362-1.512.898-2.244.898-.456 0-.78-.221-.9-.606-.096-.315-.012-.537.084-.654.192-.256.588-.385 1.188-.385.48 0 1.092.082 1.776.245.444-.303.888-.653 1.284-1.026-.18-.817-.372-2.135.12-2.742.24-.292.612-.385 1.056-.257.492.14.672.432.732.654.204.793-.732 1.866-1.368 2.496.144.549.324 1.12.552 1.645.912.397 1.992.98 2.112 1.622.048.222-.024.432-.204.607a.786.786 0 0 1-.504.198zm-1.116-1.773c.456.898.888 1.318 1.116 1.318.036 0 .084-.012.156-.07.084-.082.084-.14.072-.187-.048-.233-.432-.618-1.344-1.061zm-4.44-1.202c-.588 0-.756.14-.804.198-.012.024-.06.082-.012.245.036.14.132.28.444.28.384 0 .936-.21 1.584-.583a6.363 6.363 0 0 0-1.212-.14zm2.376-.07c.384.105.78.233 1.152.373-.132-.338-.24-.688-.336-1.026-.264.221-.54.443-.816.653zm1.488-3.768a.392.392 0 0 0-.312.14c-.252.303-.276 1.073-.084 2.053C9.014 6.9 9.41 6.2 9.314 5.826c-.012-.058-.06-.221-.396-.315a.67.67 0 0 0-.24-.046z\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75z\\" fill=\\"#FCD8C4\\"/></g></g>"},"141411":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\" d=\\"M0 0h16v16H0z\\"/><path d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2z\\" fill=\\"#FA6C42\\"/><path d=\\"M6 6h2.64c1.056 0 1.392.688 1.392 1.423 0 .7-.42 1.412-1.38 1.412H6.9v1.75H6V6zm.9 2.123h1.452c.516 0 .792-.151.792-.688 0-.56-.372-.7-.72-.7H6.9v1.388z\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75z\\" fill=\\"#FCD8C4\\"/></g></g>"},"141412":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2z\\" fill=\\"#70B2FF\\"/><path fill=\\"#FFF\\" d=\\"M9.06 6.094a1.333 1.333 0 0 1 1.983 1.778l-.097.108L8 10.926a1.833 1.833 0 0 1-2.705-2.47l.112-.123 2.475-2.475a.333.333 0 0 1 .52.412l-.048.06-2.475 2.475a1.167 1.167 0 0 0 1.548 1.74l.102-.09 2.946-2.947a.667.667 0 0 0-.86-1.013l-.083.07-2.946 2.947a.167.167 0 0 0 .192.267l.043-.031 2.475-2.475a.333.333 0 0 1 .52.41l-.048.061-2.475 2.475A.833.833 0 0 1 6.04 9.126l.074-.086 2.947-2.946z\\"/><path d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75z\\" fill=\\"#E0EFFF\\"/></g></g>"},"141413":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\" d=\\"M0 0h16v16H0z\\"/><path d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><g fill-rule=\\"nonzero\\"><path d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2z\\" fill=\\"#E5E5E5\\"/><path d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75z\\" fill=\\"#CCC\\"/></g><path d=\\"M8.229 10.473a.22.22 0 0 1 .227.214v.6c0 .117-.101.213-.227.213H7.66c-.125 0-.227-.096-.227-.214v-.599c0-.118.102-.214.227-.214h.569zM8.096 5.5c.568 0 1.03.14 1.38.435.35.288.524.682.524 1.183 0 .41-.114.748-.323 1.01a12.45 12.45 0 0 1-.751.65 1.29 1.29 0 0 0-.35.41 1.104 1.104 0 0 0-.13.534v.115H7.44v-.115c0-.312.052-.583.175-.805.113-.222.454-.567 1.022-1.043l.104-.115a.879.879 0 0 0 .236-.583c0-.271-.087-.485-.244-.641-.166-.156-.402-.23-.7-.23-.383 0-.654.107-.82.337-.148.189-.218.46-.218.805H6c0-.608.183-1.085.568-1.43.375-.345.882-.517 1.528-.517z\\" fill=\\"#999\\"/></g></g>"},"141414":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\" d=\\"M0 0h16v16H0z\\"/><path d=\\"M2.923.5h7.385L14 4.25v10.313a.93.93 0 0 1-.923.937H2.923A.93.93 0 0 1 2 14.562V1.438A.93.93 0 0 1 2.923.5z\\" fill=\\"#6E74E0\\"/><path d=\\"M9.015 9.718v2.037a.513.513 0 0 1-.147.36.499.499 0 0 1-.355.149H7.487a.5.5 0 0 1-.355-.15.513.513 0 0 1-.147-.36V9.719h2.03zm-.502 1.167H7.487v1.022h1.026v-1.022zm.486-3.204v1.022h-1.01V7.681H9zM8.002.5v1.031h1.013v1.032H8.002v.954h1.013V4.55H8.002v1.018h1.013v1.019H8.002v1.018H6.985V6.586h1.013V5.567H6.985V4.55h1.013V3.517H6.985v-1.03h1.013V1.53H6.985V.5h1.017z\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path d=\\"M10.308.5 14 4.25h-2.77a.93.93 0 0 1-.922-.938V.5z\\" fill=\\"#EBECFF\\"/></g></g>"},"141415":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2z\\" fill=\\"#2FDA84\\"/><path d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75z\\" fill=\\"#C0F7DA\\"/><path d=\\"M7.448 8.4 5.816 6.025h1.128l1.068 1.7 1.116-1.7h1.092L8.552 8.4l1.752 2.525h-1.14l-1.176-1.8-1.176 1.813H5.696z\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/></g></g>"},"141417":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\" d=\\"M0 0h16v16H0z\\"/><path d=\\"M.5 2.765C.5 2.342.836 2 1.25 2h5.13c.3 0 .572.182.69.464l.367.874h7.313c.414 0 .75.343.75.765v8.03a.757.757 0 0 1-.75.764H1.25a.757.757 0 0 1-.75-.765V2.765z\\" fill=\\"#F90\\"/><path d=\\"M2.563 4.58h10.874c.5 0 .75.256.75.766v6.882c0 .51-.25.765-.75.765H2.563c-.5 0-.75-.255-.75-.765V5.346c0-.51.25-.765.75-.765z\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path d=\\"M1.25 5.824h13.5c.5 0 .75.254.75.764v7.647c0 .51-.25.765-.75.765H1.25c-.5 0-.75-.255-.75-.765V6.588c0-.51.25-.764.75-.764z\\" fill=\\"#FCBD4B\\"/></g></g>"},"141418":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\" d=\\"M0 0h16v16H0z\\"/><path d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2z\\" fill=\\"#999\\"/><text transform=\\"translate(2 .5)\\" font-family=\\"HelveticaNeue-CondensedBold, Helvetica Neue\\" font-size=\\"6.01\\" font-style=\\"condensed\\" font-weight=\\"bold\\" fill=\\"#FFF\\"><tspan x=\\"1.2\\" y=\\"10\\">SVG</tspan></text><path d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75z\\" fill=\\"#F5F5F5\\"/></g></g>"},"146716":{"viewBox":"0 0 20 20","fill":"currentColor","content":"<g><path d=\\"M11.5 2.917h-3a.833.833 0 0 0-.833.833v10c0 .46.373.833.833.833h3c.46 0 .833-.373.833-.833v-10a.833.833 0 0 0-.833-.833zm-5.625 0h-3a.833.833 0 0 0-.833.833v13.333c0 .46.373.834.833.834h3c.46 0 .833-.373.833-.834V3.75a.833.833 0 0 0-.833-.833zm11.25 0h-3a.833.833 0 0 0-.833.833v7.5c0 .46.373.833.833.833h3c.46 0 .833-.373.833-.833v-7.5a.833.833 0 0 0-.833-.833z\\" data-follow-fill=\\"currentColor\\" fill=\\"currentColor\\"/></g>"},"149187":{"viewBox":"0 0 18 21","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path data-follow-stroke=\\"#D8D8D8\\" d=\\"M1 21V6.75C1 4.127 2.79 2 5 2h9\\" stroke=\\"#D8D8D8\\"/><path data-follow-fill=\\"#D8D8D8\\" d=\\"m17.106 2.447-2.382 1.191A.5.5 0 0 1 14 3.191V.809a.5.5 0 0 1 .724-.447l2.382 1.19a.5.5 0 0 1 0 .895z\\" fill=\\"#D8D8D8\\"/></g></g>"},"149188":{"viewBox":"0 0 17 22","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path data-follow-stroke=\\"#D8D8D8\\" d=\\"M17 21H6.615C4.066 21 2 18.851 2 16.2V3\\" stroke=\\"#D8D8D8\\"/><path data-follow-fill=\\"#D8D8D8\\" d=\\"m2.447.894 1.191 2.382A.5.5 0 0 1 3.191 4H.809a.5.5 0 0 1-.447-.724L1.552.894a.5.5 0 0 1 .895 0z\\" fill=\\"#D8D8D8\\"/></g></g>"},"168975":{"viewBox":"0 0 14 14","fill":"currentColor","content":"<g><path data-follow-stroke=\\"currentColor\\" fill=\\"none\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\" stroke=\\"currentColor\\" stroke-width=\\"1.231\\" d=\\"m7.154 1 5.538 5.538-5.538 5.231V8.385C2.846 8.385 1 13 1 13c0-5.23 1.538-8.615 6.154-8.615V1Z\\"/></g>"},"168976":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path d=\\"M9.2 6.2V3.8A1.8 1.8 0 0 0 7.4 2L5 7.4V14h6.972a1.2 1.2 0 0 0 1.2-1.02L14 7.58a1.2 1.2 0 0 0-1.2-1.38H9.2Z\\" stroke=\\"#999\\" stroke-width=\\"1.333\\" stroke-linejoin=\\"round\\"/><path d=\\"M5 7.333H3.398C2.695 7.321 2.094 7.903 2 8.6v4.2A1.386 1.386 0 0 0 3.398 14H5V7.333Z\\" stroke=\\"#3693FF\\" stroke-width=\\"1.333\\" fill=\\"#3693FF\\" fill-rule=\\"nonzero\\" stroke-linejoin=\\"round\\"/></g></g>"},"168977":{"viewBox":"0 0 17 16","fill":"currentColor","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path data-follow-fill=\\"currentColor\\" d=\\"M.164 0h16v16h-16z\\" fill-opacity=\\".01\\" fill=\\"currentColor\\" fill-rule=\\"nonzero\\"/><path d=\\"M9.364 6.2V3.8a1.8 1.8 0 0 0-1.8-1.8l-2.4 5.4V14h6.972a1.2 1.2 0 0 0 1.2-1.02l.828-5.4a1.2 1.2 0 0 0-1.2-1.38h-3.6Zm-4.2 1.133H3.562c-.703-.012-1.304.57-1.398 1.267v4.2A1.386 1.386 0 0 0 3.562 14h1.602V7.333Z\\" data-follow-stroke=\\"currentColor\\" stroke=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-width=\\"1.333\\"/></g></g>"},"171533":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M40 20c0 6.808-4.252 12.622-10.244 14.934H18.244C12.252 32.622 8 26.808 8 20c0-8.837 7.163-16 16-16s16 7.163 16 16Z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"m29.756 34.934-.68 8.149a1 1 0 0 1-.996.917h-8.16a1 1 0 0 1-.996-.917l-.68-8.15M18 17v6l6-3 6 3v-6\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"171534":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M44 6H4v30h9v5l10-5h21V6ZM14 19.5v3m10-3v3m10-3v3\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"171535":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M5.818 6.727V14h7.273\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M4 24c0 11.046 8.954 20 20 20v0c11.046 0 20-8.954 20-20S35.046 4 24 4c-7.402 0-13.865 4.021-17.323 9.998\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"m24.005 12-.001 12.009 8.48 8.48\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"193287":{"viewBox":"0 0 14 14","content":"<g><path d=\\"M12 1H2a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1ZM4 6h6M4 8h6m0-2L7.667 3.667m-1.334 6.666L4 8\\" data-follow-stroke=\\"#666\\" fill=\\"none\\" fill-rule=\\"evenodd\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\" stroke=\\"#666\\" stroke-width=\\"1.33\\"/></g>"},"193323":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M6 6v36h36\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"m14 34 8-16 10 9L42 6\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"199049":{"viewBox":"0 0 16 15","fill":"currentColor","content":"<g><g data-follow-stroke=\\"currentColor\\" fill=\\"none\\" stroke=\\"currentColor\\" stroke-width=\\"1.2\\" transform=\\"translate(1.2 .6)\\"><g transform=\\"translate(0 7.2)\\"><path d=\\"M12 2.4v-.8A1.6 1.6 0 0 0 10.4 0H3.2a1.6 1.6 0 0 0-1.6 1.6v.8\\" stroke-linejoin=\\"round\\"/><rect y=\\"2.6\\" width=\\"3.2\\" height=\\"3.2\\" rx=\\"1.2\\"/><rect x=\\"10.4\\" y=\\"2.6\\" width=\\"3.2\\" height=\\"3.2\\" rx=\\"1.2\\"/></g><rect x=\\"4.4\\" width=\\"4.8\\" height=\\"4.8\\" rx=\\"1.6\\"/><rect x=\\"5.2\\" y=\\"9.8\\" width=\\"3.2\\" height=\\"3.2\\" rx=\\"1.2\\"/><path d=\\"M6.8 4.8v2.4\\"/></g></g>"},"201785":{"viewBox":"0 0 16 16","fill":"currentColor","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"currentColor\\" fill-rule=\\"nonzero\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M8 14.667A6.667 6.667 0 1 0 8 1.333a6.667 6.667 0 0 0 0 13.334Z\\" stroke=\\"currentColor\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M5.333 8h5.334\\" stroke=\\"currentColor\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g></g>"},"210081":{"viewBox":"0 0 13 13","fill":"currentColor","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"m1.054 6.45-.062.065a.567.567 0 0 0 .448.92h2.855l.001 4.367c0 .313.256.566.572.566h3.999l.084-.006a.568.568 0 0 0 .487-.56V7.434h2.857c.52 0 .77-.634.386-.983L7.253 1.517a.575.575 0 0 0-.772 0L1.054 6.451Z\\" fill=\\"currentColor\\"/></g>"},"210082":{"viewBox":"0 0 12 13","fill":"currentColor","content":"<g><path data-follow-fill=\\"currentColor\\" d=\\"m1.921 4.505 6.649 6.649v.28a.567.567 0 0 1-.397.54l-.089.02L8 12H4a.57.57 0 0 1-.563-.475l-.008-.092V7.066H.571a.568.568 0 0 1-.498-.845l.051-.074.061-.065L1.92 4.505Zm.18-2.82.083.07 8.485 8.486a.665.665 0 0 1-.858 1.01l-.083-.07-8.485-8.485a.665.665 0 0 1 .858-1.01ZM6.31 1.09l.077.059 5.428 4.933a.566.566 0 0 1-.292.977l-.094.008-2.803-.001-4.534-4.535 1.523-1.382a.575.575 0 0 1 .695-.059Z\\" fill=\\"currentColor\\"/></g>"},"210635":{"viewBox":"0 0 15 15","fill":"currentColor","content":"<g><g data-follow-stroke=\\"currentColor\\" fill=\\"none\\" fill-rule=\\"evenodd\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\" stroke=\\"currentColor\\" transform=\\"translate(1 1)\\"><circle cx=\\"6.667\\" cy=\\"6.667\\" r=\\"6.667\\"/><path d=\\"M6.667 0a6.667 6.667 0 0 1 6.666 6.667H6.667V0Z\\"/></g></g>"},"210636":{"viewBox":"0 0 13 15","fill":"currentColor","content":"<g><g data-follow-stroke=\\"currentColor\\" fill=\\"none\\" fill-rule=\\"evenodd\\" stroke-linecap=\\"round\\" stroke=\\"currentColor\\"><path d=\\"M11.667 10.667v3a.667.667 0 0 1-.667.666H8.833\\" stroke-linejoin=\\"round\\"/><path d=\\"M11.667 5.233v-3.25a.658.658 0 0 0-.667-.65H1.667a.658.658 0 0 0-.667.65v11.7c0 .36.298.65.667.65h9\\" stroke-linejoin=\\"round\\"/><path d=\\"M3.667 5h4.666M8 12.333 12.5 6.5M3.667 7.666h4.666m-4.666 3h2.666\\"/></g></g>"},"219025":{"viewBox":"0 0 13 13","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path d=\\"M0 0h13v13H0z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path d=\\"M0 0h13v13H0z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path data-follow-stroke=\\"#3693FF\\" d=\\"M7.475 5.037v-1.95c0-.807-.655-1.462-1.462-1.462l-1.95 4.388v5.362h5.664a.975.975 0 0 0 .975-.829l.673-4.387a.975.975 0 0 0-.975-1.122H7.475Z\\" stroke=\\"#3693FF\\" fill=\\"#3693FF\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"#3693FF\\" d=\\"M4.063 5.958H2.76c-.571-.01-1.06.463-1.136 1.03V10.4c.077.566.565.985 1.136.975h1.301V5.958Z\\" stroke=\\"#3693FF\\" stroke-linejoin=\\"round\\"/></g></g>"},"219026":{"viewBox":"0 0 16 16","fill":"currentColor","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><circle data-follow-fill=\\"currentColor\\" fill=\\"currentColor\\" cx=\\"8\\" cy=\\"8\\" r=\\"8\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"m4.727 8.108 2.109 2.074 4.437-4.364\\" stroke=\\"currentColor\\" stroke-width=\\"1.091\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g></g>"},"219027":{"viewBox":"0 0 16 16","fill":"currentColor","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><circle data-follow-fill=\\"currentColor\\" fill=\\"currentColor\\" cx=\\"8\\" cy=\\"8\\" r=\\"8\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"m4.727 8.108 2.109 2.074 4.437-4.364\\" stroke=\\"currentColor\\" stroke-width=\\"1.091\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g></g>"},"219962":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" clip-rule=\\"evenodd\\" d=\\"M24 41c9.941 0 18-8.322 18-14 0-5.678-8.059-14-18-14S6 21.328 6 27c0 5.672 8.059 14 18 14Z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M24 33a6 6 0 1 0 0-12 6 6 0 0 0 0 12Z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"m13.264 11.266 2.594 3.62m19.767-3.176-2.595 3.62M24.009 7v6\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\"/></g>"},"220895":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path data-follow-stroke=\\"currentColor\\" d=\\"M22 8.012c-1.5 0-5.929-.074-7 4.989C13.917 18.117 9.857 22.848 8 24m14 16c-1.5 0-5.929.063-7-5-1.083-5.117-5.143-9.848-7-11\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><circle data-follow-fill=\\"currentColor\\" cx=\\"8\\" cy=\\"24\\" r=\\"4\\" fill=\\"currentColor\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M8 24h14m8 .001h12m-12-16h12m-12 32h12\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"223220":{"viewBox":"0 0 48 48","fill":"none","content":"<g><circle data-follow-stroke=\\"currentColor\\" cx=\\"16\\" cy=\\"10\\" r=\\"4\\" stroke=\\"currentColor\\" stroke-width=\\"4\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M28 38H13c-4 0-7-2.917-7-7s3-7 7-7h7m0 0h15c4 0 7-2.917 7-7s-3-7-7-7H20M6 10h6m24 28h6\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><circle data-follow-stroke=\\"currentColor\\" cx=\\"32\\" cy=\\"38\\" r=\\"4\\" stroke=\\"currentColor\\" stroke-width=\\"4\\"/></g>"},"224429":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M17 6h14v9H17zM6 33h14v9H6zm22 0h14v9H28z\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M24 16v8m-11 9v-9h22v9\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"224908":{"viewBox":"0 0 16 17","content":"<g><g data-follow-fill=\\"#FFF\\" fill-rule=\\"evenodd\\" fill=\\"#FFF\\"><path d=\\"m8.514 1.009 6.57 3.942a.6.6 0 0 1-.03 1.045l-6.59 3.46a1 1 0 0 1-.929 0l-6.59-3.46a.6.6 0 0 1-.03-1.045l6.57-3.942a1 1 0 0 1 1.03 0Z\\"/><path d=\\"m.5 7.2 7.025 3.62c.309.159.675.159.984-.001L15.5 7.2v2.082L8.49 12.81a1.08 1.08 0 0 1-.812.054l-.13-.053L.5 9.282V7.2Zm0 3.282 7.025 3.62c.309.159.675.158.984-.001l6.991-3.62v2.083l-7.01 3.527a1.08 1.08 0 0 1-.812.054l-.13-.053L.5 12.564v-2.082Z\\" opacity=\\".5\\"/></g></g>"},"226619":{"viewBox":"0 0 50 50","content":"<g><g data-follow-fill=\\"#3693FF\\" fill-rule=\\"evenodd\\" fill=\\"#3693FF\\" transform=\\"scale(-1 1) rotate(-45 5.657 71.698)\\"><circle cx=\\"7.286\\" cy=\\"7.286\\" r=\\"7.286\\"/><circle fill-opacity=\\".75\\" cx=\\"26.714\\" cy=\\"7.286\\" r=\\"7.286\\"/><circle fill-opacity=\\".279\\" cx=\\"26.714\\" cy=\\"26.714\\" r=\\"7.286\\"/><circle fill-opacity=\\".136\\" cx=\\"7.286\\" cy=\\"26.714\\" r=\\"7.286\\"/></g></g>"},"234676":{"viewBox":"0 0 16 16","fill":"currentColor","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path data-follow-fill=\\"currentColor\\" d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"currentColor\\" fill-rule=\\"nonzero\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M1.667 6.333h12.666v7a.667.667 0 0 1-.666.667H2.333a.667.667 0 0 1-.666-.667v-7Zm0-3.333c0-.368.298-.667.666-.667h11.334c.368 0 .666.299.666.667v3.333H1.667V3Z\\" stroke=\\"currentColor\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M5.333 1.333V4m5.334-2.667V4m-1.334 7.333h2m-6.666 0h2m2.666-2.666h2m-6.666 0h2\\" stroke=\\"currentColor\\" stroke-linecap=\\"round\\"/></g></g>"},"279264":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path d=\\"M0 0h48v48H0z\\" fill=\\"#fff\\" fill-opacity=\\".01\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"M26 24h18m-30 0h4m0 14h26M6 38h4m8-28h26M6 10h4\\" stroke=\\"currentColor\\" stroke-width=\\"4\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g>"},"291587":{"viewBox":"0 0 24 24","fill":"currentColor","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path data-follow-fill=\\"currentColor\\" d=\\"M4 4h16v16H4z\\" fill-opacity=\\".01\\" fill=\\"currentColor\\" fill-rule=\\"nonzero\\"/><path data-follow-stroke=\\"currentColor\\" d=\\"m15.833 10.5-4 4-4-4\\" stroke=\\"currentColor\\" stroke-width=\\"1.333\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g></g>"},"291588":{"viewBox":"0 0 24 24","fill":"currentColor","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\" d=\\"M4 4h16v16H4z\\"/><path d=\\"M4 4h16v16H4z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path data-follow-fill=\\"currentColor\\" d=\\"M11.862 9.529a.667.667 0 0 1 .86-.07l.083.07 4 4a.667.667 0 0 1-.86 1.013l-.083-.07-3.529-3.529-3.528 3.528a.667.667 0 0 1-.86.07l-.083-.07a.667.667 0 0 1-.07-.86l.07-.082 4-4Z\\" fill=\\"currentColor\\"/></g></g>"},"295729":{"viewBox":"0 0 16 17","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\" transform=\\"translate(0 .5)\\"><rect fill=\\"#70B2FF\\" width=\\"16\\" height=\\"16\\" rx=\\"2\\"/><g fill=\\"#FFF\\"><path d=\\"M1 1h14v14H1z\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\"/><path d=\\"m4.251 14.02.078-.066a.585.585 0 0 1-.326.165l-.02.002a.587.587 0 0 1-.048.004h-.041a.586.586 0 0 1-.052-.005l.075.005a.585.585 0 0 1-.385-.145l-.028-.026-1.75-1.75a.583.583 0 0 1 .753-.886l.072.061.754.754V7.125c0-.293.216-.535.497-.577l.087-.006H9.75a.583.583 0 0 1 .086 1.16l-.086.006H4.5v4.425l.754-.754a.583.583 0 0 1 .887.753l-.062.072-1.753 1.753a.586.586 0 0 1-.075.063Zm7.907-12.14-.007-.001.058.01a.604.604 0 0 1 .249.122l.038.035 1.75 1.75a.583.583 0 0 1-.753.886l-.072-.061-.755-.755v6.176a.583.583 0 0 1-.496.577l-.087.006H6.25a.583.583 0 0 1-.086-1.16l.086-.007h5.25V3.867l-.754.754a.583.583 0 0 1-.753.061l-.072-.061a.583.583 0 0 1-.062-.753l.062-.072 1.75-1.75.067-.058.005-.004-.002.001-.003.003-.009.006.012-.009.038-.024a.598.598 0 0 1 .218-.08l.02-.002a.587.587 0 0 1 .048-.004h.041l.034.003-.057-.003.068.004v-.001l.007.002Z\\"/></g></g></g>"},"295730":{"viewBox":"0 0 16 17","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\" transform=\\"translate(0 .5)\\"><rect fill=\\"#FCBD4B\\" width=\\"16\\" height=\\"16\\" rx=\\"2\\"/><g fill=\\"#FFF\\"><path d=\\"M1 1h14v13H1z\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\"/><path d=\\"M7.886 4.75c1.865 0 3.39 1.38 3.489 3.119l.005.181-.001 3.849 2.039.001c.321 0 .582.246.582.55a.561.561 0 0 1-.496.544l-.086.006-2.609-.001-.011.001H2.646c-.321 0-.582-.246-.582-.55a.56.56 0 0 1 .496-.544l.086-.006 1.746-.001V8.05c0-1.762 1.462-3.201 3.303-3.295l.191-.005Zm0 1.1c-1.232 0-2.241.905-2.323 2.05l-.006.15v3.85h4.658V8.05c0-1.117-.882-2.04-2.024-2.181l-.157-.015-.148-.004Zm5.878.809a.548.548 0 0 1-.389.617l-.084.02-.86.143c-.316.053-.618-.147-.674-.446a.548.548 0 0 1 .388-.617l.084-.02.86-.144c.317-.052.619.147.675.447ZM2.598 6.204l.085.008.86.144c.317.052.529.338.473.637a.575.575 0 0 1-.589.454l-.086-.008-.86-.143c-.316-.053-.528-.338-.472-.637a.575.575 0 0 1 .589-.455Zm9.125-2.885a.53.53 0 0 1 .126.702l-.055.073-.561.632a.606.606 0 0 1-.82.068.53.53 0 0 1-.127-.702l.055-.073.561-.632a.606.606 0 0 1 .82-.068Zm-6.92.004.067.064.562.632a.53.53 0 0 1-.072.775.609.609 0 0 1-.754-.005l-.066-.063-.562-.632a.53.53 0 0 1 .072-.775.609.609 0 0 1 .754.004ZM7.887 2c.293 0 .535.204.576.469l.007.081v.825c0 .304-.261.55-.583.55a.573.573 0 0 1-.576-.469l-.006-.081V2.55c0-.304.26-.55.582-.55Z\\"/></g></g></g>"},"295731":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\" d=\\"M0 0h16v16H0z\\"/><rect fill=\\"#E0EFFF\\" width=\\"16\\" height=\\"16\\" rx=\\"2\\"/><path data-follow-stroke=\\"#3693FF\\" d=\\"M8 2.3c1.105 0 2.105.448 2.828 1.172a4 4 0 0 1-.827 6.293V10.8H6V9.765a4 4 0 0 1-.828-6.293A3.987 3.987 0 0 1 8 2.3ZM5 13.8h6\\" stroke=\\"#3693FF\\" stroke-width=\\"2\\"/></g></g>"},"295732":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path d=\\"M0 0h16v16H0z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><rect fill=\\"#D2F9F4\\" width=\\"16\\" height=\\"16\\" rx=\\"2\\"/><path d=\\"M4 4.5v2H2v-2h2Zm0 5v2H2v-2h2Zm2-5h8v2H6v-2Zm0 5h8v2H6v-2Z\\" fill=\\"#2EC6C1\\"/></g></g>"},"358989":{"viewBox":"0 0 26 26","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><circle fill=\\"#EEE\\" cx=\\"13\\" cy=\\"13\\" r=\\"13\\"/><path d=\\"M5 5h16v16H5z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path d=\\"M5 5h16v16H5z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\" fill-rule=\\"nonzero\\"/><path data-follow-stroke=\\"#666\\" d=\\"M15 11.333h-3.333a2.667 2.667 0 1 0 0 5.334H17a2.667 2.667 0 0 0 2-4.43\\" stroke=\\"#666\\" stroke-width=\\"1.333\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/><path data-follow-stroke=\\"#666\\" d=\\"M7 13.097a2.667 2.667 0 0 1 2-4.43h5.333a2.667 2.667 0 1 1 0 5.333H11\\" stroke=\\"#666\\" stroke-width=\\"1.333\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\"/></g></g>"},"375984":{"viewBox":"0 0 24 24","content":"<g><path d=\\"M11.5 4a7 7 0 0 1 5.216 11.669l2.693 2.78a.75.75 0 0 1-1.022 1.096l-.056-.052-2.73-2.82A7 7 0 1 1 11.5 4Zm0 1.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11Z\\" fill=\\"#909399\\" fill-rule=\\"evenodd\\" data-follow-fill=\\"#909399\\"/></g>"},"375985":{"viewBox":"0 0 34 34","content":"<g><g fill=\\"#FFF\\" fill-rule=\\"evenodd\\" data-follow-fill=\\"#FFF\\"><circle r=\\"17\\" cy=\\"17\\" cx=\\"17\\" opacity=\\".2\\"/><g fill-rule=\\"nonzero\\"><path d=\\"M16.917 6c4.372 0 7.916 3.607 7.916 8.056a8.09 8.09 0 0 1-3.164 6.443l-.002 2.418h-9.5V20.5A8.09 8.09 0 0 1 9 14.056C9 9.606 12.544 6 16.917 6Zm0 3.222c-2.624 0-4.75 2.164-4.75 4.834 0 1.432.613 2.755 1.654 3.665l.247.203 1.265.967-.001.802h3.17l.001-.804 1.263-.966a4.85 4.85 0 0 0 1.9-3.867c0-2.67-2.126-4.834-4.75-4.834ZM21.667 24.528v3.222h-9.5v-3.222z\\"/></g></g></g>"},"375986":{"viewBox":"0 0 15 15","content":"<g><g fill=\\"none\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h15v15H0z\\"/><path data-follow-fill=\\"#606266\\" fill=\\"#606266\\" d=\\"M6.38 1.402a.623.623 0 0 1 .182.449v11.274a.625.625 0 0 1-1.243.092l-.006-.092V3.351L2.628 6.036a.625.625 0 0 1-.956-.798l.073-.086 3.75-3.75a.625.625 0 0 1 .883 0Zm2.683-.12c.313 0 .573.23.618.532l.007.092v9.74l2.683-2.682a.625.625 0 0 1 .956.798l-.073.086-3.75 3.75-.009.01a.628.628 0 0 1-.061.051l.07-.06a.628.628 0 0 1-.441.182h-.026a.628.628 0 0 1-.051-.004l.076.004a.627.627 0 0 1-.485-.231l.044.048a.622.622 0 0 1-.175-.341l-.002-.008-.007-.093V1.906c0-.345.28-.625.626-.625Z\\"/></g></g>"},"375987":{"viewBox":"0 0 15 15","content":"<g><path d=\\"m1.626 2-.097.007a.625.625 0 0 0-.378 1.024l4.35 5.08v3.715c0 .238.135.455.348.56l2.25 1.112.084.034a.625.625 0 0 0 .818-.595V8.111l4.35-5.08A.625.625 0 0 0 12.876 2H1.626Zm9.892 1.25L7.901 7.473l-.052.072a.625.625 0 0 0-.098.335v4.05l-1-.493V7.88l-.006-.09a.625.625 0 0 0-.144-.317L2.983 3.25h8.535Z\\" fill-rule=\\"nonzero\\" fill=\\"#606266\\" data-follow-fill=\\"#606266\\"/></g>"},"375989":{"viewBox":"0 0 34 34","content":"<g><g fill=\\"#FFF\\" fill-rule=\\"evenodd\\" data-follow-fill=\\"#FFF\\"><circle r=\\"17\\" cy=\\"17\\" cx=\\"17\\" opacity=\\".2\\"/><path fill-rule=\\"nonzero\\" fill-opacity=\\".01\\" d=\\"M5 4h25.333v25.778H5z\\"/><path d=\\"M11.333 11.25v3.222H8.167V11.25h3.166Zm0 8.056v3.222H8.167v-3.222h3.166ZM14.5 11.25h12.667v3.222H14.5V11.25Zm0 8.056h12.667v3.222H14.5v-3.222Z\\"/></g></g>"},"375991":{"viewBox":"0 0 20 18","content":"<g><text transform=\\"translate(-678 -1477)\\" fill=\\"#FFF\\" font-size=\\"16\\" font-family=\\"AppleColorEmoji, Apple Color Emoji\\" fill-rule=\\"evenodd\\" data-follow-fill=\\"#FFF\\"><tspan y=\\"1493\\" x=\\"678\\">☕️</tspan></text></g>"},"387996":{"viewBox":"0 0 24 24","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><rect fill=\\"#3693FF\\" width=\\"24\\" height=\\"24\\" rx=\\"4\\"/><g fill=\\"#FFF\\"><path fill-opacity=\\".01\\" fill-rule=\\"nonzero\\" d=\\"M4 4h15.96v15.96H4z\\"/><path d=\\"M4 4h15.96v15.96H4z\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\"/><path d=\\"M12.001 6.66c.334 0 .61.247.657.568l.007.098-.006 3.989h3.976a.665.665 0 0 1 .098 1.323l-.098.007h-3.977l-.005 3.99a.665.665 0 0 1-1.323.097l-.007-.098.005-3.989H7.325a.665.665 0 0 1-.098-1.323l.098-.007h4.004l.006-3.99c0-.368.299-.665.666-.665Z\\"/></g></g></g>"},"388499":{"viewBox":"0 0 24 24","fill":"currentColor","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><rect data-follow-fill=\\"currentColor\\" fill=\\"currentColor\\" stroke=\\"#CCC\\" x=\\".5\\" y=\\".5\\" width=\\"23\\" height=\\"23\\" rx=\\"4\\"/><g stroke=\\"#666\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\" stroke-width=\\"1.278\\"><path d=\\"M18 12.333h-4m2 2-2-2 2-2M11 6v6.667c0 2.246-2.055 4.522-4 5.333\\"/><path d=\\"M18 8.667V7a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1v-1.167\\"/></g></g></g>"},"408147":{"viewBox":"0 0 24 24","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M8 0h16v16H8z\\"/><rect rx=\\"4\\" height=\\"24\\" width=\\"24\\" fill=\\"#E0EFFF\\"/><path stroke-width=\\"2\\" stroke=\\"#3693FF\\" d=\\"M12 6.3a4 4 0 0 1 2.001 7.465V14.8H10v-1.035A4 4 0 0 1 12 6.3ZM9 17.8h6\\" data-follow-stroke=\\"#3693FF\\"/></g></g>"},"408148":{"viewBox":"0 0 24 24","content":"<g><g fill-rule=\\"nonzero\\" fill=\\"none\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M8 2h16v16H8z\\"/><g><rect rx=\\"4\\" height=\\"24\\" width=\\"24\\" fill=\\"#FCD8C4\\"/><path fill=\\"#ED4014\\" d=\\"M10.185 6.525h4.243a.23.23 0 0 1 .217.306l-.96 2.727a.23.23 0 0 0 .217.305h2.677a.23.23 0 0 1 .19.36l-5.647 8.203a.23.23 0 0 1-.414-.17l.91-5.074a.23.23 0 0 0-.225-.269h-2.99a.23.23 0 0 1-.22-.296l1.782-5.929a.23.23 0 0 1 .22-.164v.001Z\\"/></g></g></g>"},"408149":{"viewBox":"0 0 20 20","content":"<g><defs><linearGradient id=\\"a\\" y2=\\"100%\\" x2=\\"50%\\" y1=\\"3.062%\\" x1=\\"50%\\"><stop offset=\\"0%\\" stop-color=\\"#8EF3CE\\"/><stop offset=\\"100%\\" stop-color=\\"#48D09F\\"/></linearGradient></defs><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h20v20H0z\\" data-follow-fill=\\"#FFF\\"/><path fill=\\"url(#a)\\" d=\\"M10 .833a9.167 9.167 0 1 0 0 18.334A9.167 9.167 0 0 0 10 .833Z\\"/><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" d=\\"M12.917 6.667c.425 0 .775.318.827.728l.006.105v.417a.833.833 0 0 1-1.66.104l-.007-.104V7.5c0-.46.373-.833.834-.833ZM7.083 6.667c.425 0 .776.318.827.728l.007.105v.417a.833.833 0 0 1-1.66.104l-.007-.104V7.5c0-.46.373-.833.833-.833ZM6.71 12.171a.833.833 0 0 1 1.119.373c.06.12.222.35.485.583.44.392.99.623 1.686.623s1.246-.231 1.686-.623c.263-.234.425-.462.485-.583a.833.833 0 1 1 1.491.745c-.148.296-.429.693-.869 1.084-.731.65-1.666 1.044-2.793 1.044-1.127 0-2.062-.394-2.793-1.044-.44-.391-.721-.788-.869-1.084a.833.833 0 0 1 .373-1.118Z\\" data-follow-fill=\\"#FFF\\"/></g></g>"},"408150":{"viewBox":"0 0 24 24","content":"<g><g fill-rule=\\"nonzero\\" fill=\\"none\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h16v16H0z\\"/><rect rx=\\"4\\" height=\\"24\\" width=\\"24\\" fill=\\"#EBECFF\\"/><path fill=\\"#6E74E0\\" d=\\"M14.191 10.63a.324.324 0 0 1 .459-.01l3.297 3.146.01.01c.124.13.12.334-.01.458L14.65 17.38a.324.324 0 0 1-.548-.234v-2.03h-2.744a.324.324 0 0 1-.324-.325V13.21c0-.179.145-.324.324-.324h2.744v-2.03c0-.084.032-.164.09-.224l-.001-.002Zm-4.815-4c.057.06.09.14.09.224v2.031h2.744c.179 0 .324.145.324.324v1.582a.324.324 0 0 1-.324.324H9.466v2.03a.324.324 0 0 1-.548.235L5.62 10.234a.324.324 0 0 1-.01-.458l.01-.01L8.918 6.62a.324.324 0 0 1 .458.01Z\\"/></g></g>"},"408151":{"viewBox":"0 0 32 32","content":"<g><defs><linearGradient id=\\"a\\" y2=\\"100%\\" x2=\\"50%\\" y1=\\"0%\\" x1=\\"50%\\"><stop offset=\\"0%\\" stop-color=\\"#66C5FF\\"/><stop offset=\\"100%\\" stop-color=\\"#3693FF\\"/></linearGradient></defs><g fill-rule=\\"evenodd\\" fill=\\"none\\"><circle r=\\"16\\" cy=\\"16\\" cx=\\"16\\" fill=\\"#E0EFFF\\"/><g fill-rule=\\"nonzero\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M6 6h20v20H6z\\"/><path fill=\\"url(#a)\\" d=\\"M10 .833a9.167 9.167 0 1 1 0 18.334A9.167 9.167 0 0 1 10 .833Zm.004 3.334A.833.833 0 0 0 9.17 5v5.004l.007.11c.024.18.106.349.237.479l3.533 3.533.085.075a.834.834 0 0 0 1.093-.075l.075-.085a.834.834 0 0 0-.075-1.094l-3.289-3.289V5l-.006-.104a.833.833 0 0 0-.826-.73Z\\" transform=\\"translate(6 6)\\"/></g></g></g>"},"408153":{"viewBox":"0 0 20 20","content":"<g><defs><linearGradient id=\\"a\\" y2=\\"100%\\" x2=\\"50%\\" y1=\\"3.062%\\" x1=\\"50%\\"><stop offset=\\"0%\\" stop-color=\\"#F17F62\\"/><stop offset=\\"100%\\" stop-color=\\"#ED4014\\"/></linearGradient></defs><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h20v20H0z\\" data-follow-fill=\\"#FFF\\"/><path fill=\\"url(#a)\\" d=\\"M10 .833a9.167 9.167 0 1 0 0 18.334A9.167 9.167 0 0 0 10 .833Z\\"/><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" d=\\"M12.917 6.667c.425 0 .775.318.827.728l.006.105v.417a.833.833 0 0 1-1.66.104l-.007-.104V7.5c0-.46.373-.833.834-.833ZM7.083 6.667c.425 0 .776.318.827.728l.007.105v.417a.833.833 0 0 1-1.66.104l-.007-.104V7.5c0-.46.373-.833.833-.833ZM6.71 14.329a.833.833 0 0 0 1.119-.373c.06-.12.222-.35.485-.583.44-.392.99-.623 1.686-.623s1.246.231 1.686.623c.263.234.425.462.485.583a.833.833 0 1 0 1.491-.746c-.148-.295-.429-.692-.869-1.083-.731-.65-1.666-1.044-2.793-1.044-1.127 0-2.062.394-2.793 1.044-.44.391-.721.788-.869 1.083a.833.833 0 0 0 .373 1.119Z\\" data-follow-fill=\\"#FFF\\"/></g></g>"},"408154":{"viewBox":"0 0 24 24","content":"<g><g fill-rule=\\"nonzero\\" fill=\\"none\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h16v16H0z\\"/><rect rx=\\"4\\" height=\\"24\\" width=\\"24\\" fill=\\"#D2F9F4\\"/><path fill=\\"#2EC6C1\\" d=\\"M8 13.5v2H6v-2h2Zm10 0v2h-8v-2h8Zm-10-5v2H6v-2h2Zm10 0v2h-8v-2h8Z\\"/></g></g>"},"408155":{"viewBox":"0 0 32 32","content":"<g><defs><linearGradient id=\\"a\\" y2=\\"100%\\" x2=\\"50%\\" y1=\\"0%\\" x1=\\"50%\\"><stop offset=\\"0%\\" stop-color=\\"#66C5FF\\"/><stop offset=\\"100%\\" stop-color=\\"#3693FF\\"/></linearGradient></defs><g fill-rule=\\"evenodd\\" fill=\\"none\\"><circle r=\\"16\\" cy=\\"16\\" cx=\\"16\\" fill=\\"#E0EFFF\\"/><g fill-rule=\\"nonzero\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M6 6h20v20H6z\\"/><path fill=\\"url(#a)\\" d=\\"M18 18.167a8 8 0 1 0-16 0h16Z\\" transform=\\"translate(6 5.833)\\"/><path opacity=\\".5\\" fill=\\"#3693FF\\" d=\\"M16 5.833A4.583 4.583 0 1 0 16 15a4.583 4.583 0 0 0 0-9.167Z\\"/></g></g></g>"},"409691":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><rect fill=\\"#EBECFF\\" width=\\"16\\" height=\\"16\\" rx=\\"2\\"/><path d=\\"M2 2h12v12H2z\\" fill-opacity=\\".01\\" fill=\\"#FFF\\"/><path d=\\"M3.5 3.5H7v2.75H3.5zM9 9.75h3.5v2.75H9zM9 3.5h3.5v4.25H9zM3.5 8.25H7v4.25H3.5z\\" data-follow-stroke=\\"#6E74E0\\" stroke=\\"#6E74E0\\"/></g></g>"},"410075":{"viewBox":"0 0 16 16","content":"<g><path d=\\"M13.592 2.083a6.274 6.274 0 0 1 1.701 4.495 7.113 7.113 0 0 1-1.4 4.199 3.983 3.983 0 0 1-3.18 1.87 1.283 1.283 0 0 1-1.087-.3 1.363 1.363 0 0 1-.457-1.059 2.833 2.833 0 0 1-2.46 1.346 2.915 2.915 0 0 1-2.238-.915 3.42 3.42 0 0 1-.864-2.41 6.204 6.204 0 0 1 1.387-4.036A3.895 3.895 0 0 1 8.24 3.537c.903-.017 1.7.607 1.923 1.507l.314-1.09h1.741l-1.453 5.383c-.152.466-.25.95-.288 1.44 0 .31.158.457.485.457a2.353 2.353 0 0 0 1.793-1.21A5.363 5.363 0 0 0 13.8 6.671a4.766 4.766 0 0 0-1.413-3.58 5.74 5.74 0 0 0-4.214-1.547 5.934 5.934 0 0 0-4.567 1.87 6.662 6.662 0 0 0-1.714 4.738 6.26 6.26 0 0 0 1.806 4.858 6.718 6.718 0 0 0 4.724 1.534 8.518 8.518 0 0 0 3.56-.686A5.84 5.84 0 0 0 14.141 12H16a6.909 6.909 0 0 1-3.22 3.055c-1.37.63-2.856.947-4.357.929a8.64 8.64 0 0 1-6.19-2.126A7.65 7.65 0 0 1 .008 8.085a7.747 7.747 0 0 1 2.173-5.638A8.006 8.006 0 0 1 8.279.01a6.908 6.908 0 0 1 5.313 2.072ZM6.434 6.538a4.649 4.649 0 0 0-.916 2.893c-.027.434.088.865.327 1.225.252.314.639.48 1.034.444.482 0 .947-.183 1.308-.512.43-.343.75-.812.916-1.345l.42-1.602c.118-.363.201-.737.248-1.117-.007-.65-.519-1.177-1.152-1.184a2.599 2.599 0 0 0-2.185 1.198Z\\" fill-rule=\\"nonzero\\" fill=\\"#3693FF\\" data-follow-fill=\\"#3693FF\\"/></g>"},"411538":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"M24.008 14.1V42M12 26l12-12 12 12M12 6h24\\" data-follow-stroke=\\"currentColor\\"/></g>"},"411540":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path fill-opacity=\\".01\\" fill=\\"#fff\\" d=\\"M0 0h48v48H0z\\"/><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"M26 24h18M14 24h4M18 38h26M6 38h4M18 10h26M6 10h4\\" data-follow-stroke=\\"currentColor\\"/></g>"},"424894":{"viewBox":"0 0 16 17","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 .667h16v16H0z\\"/><path fill=\\"#333\\" d=\\"M1.333 14.667h13.334H1.333Z\\"/><path fill-rule=\\"nonzero\\" fill=\\"#3693FF\\" d=\\"M1.333 15.333a.667.667 0 0 1-.098-1.326L1.333 14H2v-4c0-.335.247-.612.568-.66l.099-.007h2c.368 0 .666.299.666.667v4h1V6.667c0-.335.247-.612.568-.66L7 6h2c.368 0 .667.298.667.667V14h1V2.667c0-.335.246-.612.568-.66L11.333 2h2c.369 0 .667.298.667.667V14h.667a.667.667 0 0 1 .098 1.326l-.098.007H1.333Z\\"/></g></g>"},"424895":{"viewBox":"0 0 14 14","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h14v14H0z\\" data-follow-fill=\\"#FFF\\"/><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke=\\"#333\\" d=\\"M8.75 1.75h3.5v3.5M5.25 12.25h-3.5v-3.5M12.25 1.75 8.458 5.542M5.542 8.458 1.75 12.25\\" data-follow-stroke=\\"#333\\"/></g></g>"},"427317":{"viewBox":"0 0 16 17","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 .667h16v16H0z\\"/><path fill=\\"#333\\" d=\\"M1.333 14.667h13.334H1.333Z\\"/><path fill-rule=\\"nonzero\\" fill=\\"#3693FF\\" d=\\"M1.333 15.333a.667.667 0 0 1-.098-1.326L1.333 14H2v-4c0-.335.247-.612.568-.66l.099-.007h2c.368 0 .666.299.666.667v4h1V6.667c0-.335.247-.612.568-.66L7 6h2c.368 0 .667.298.667.667V14h1V2.667c0-.335.246-.612.568-.66L11.333 2h2c.369 0 .667.298.667.667V14h.667a.667.667 0 0 1 .098 1.326l-.098.007H1.333Z\\"/></g></g>"},"427318":{"viewBox":"0 0 14 14","content":"<g><g fill-rule=\\"evenodd\\" fill=\\"none\\"><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h14v14H0z\\" data-follow-fill=\\"#FFF\\"/><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke=\\"#333\\" d=\\"M8.75 1.75h3.5v3.5M5.25 12.25h-3.5v-3.5M12.25 1.75 8.458 5.542M5.542 8.458 1.75 12.25\\" data-follow-stroke=\\"#333\\"/></g></g>"},"453634":{"viewBox":"0 0 22 22","content":"<g><defs><filter id=\\"a\\" filterUnits=\\"objectBoundingBox\\" height=\\"296.1%\\" width=\\"296.1%\\" y=\\"-98.1%\\" x=\\"-98.1%\\"><feOffset result=\\"shadowOffsetOuter1\\" in=\\"SourceAlpha\\" dy=\\"2\\"/><feGaussianBlur result=\\"shadowBlurOuter1\\" in=\\"shadowOffsetOuter1\\" stdDeviation=\\"1.5\\"/><feColorMatrix result=\\"shadowMatrixOuter1\\" in=\\"shadowBlurOuter1\\" values=\\"0 0 0 0 0.211764706 0 0 0 0 0.576470588 0 0 0 0 1 0 0 0 0.255627185 0\\"/><feMerge><feMergeNode in=\\"shadowMatrixOuter1\\"/><feMergeNode in=\\"SourceGraphic\\"/></feMerge></filter></defs><g fill-rule=\\"evenodd\\" fill=\\"none\\"><g><circle r=\\"11\\" cy=\\"11\\" cx=\\"11\\" fill=\\"#E0EFFF\\"/><path fill-rule=\\"nonzero\\" fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M4.231 4.231h13.538v13.538H4.231z\\"/></g><g transform=\\"translate(5.359 5.359)\\" filter=\\"url(#a)\\"><path fill-rule=\\"nonzero\\" fill=\\"#3693FF\\" d=\\"M5.641 0a3.949 3.949 0 0 0-3.949 3.949v5.64H9.59V3.95A3.949 3.949 0 0 0 5.64 0Z\\"/><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"1.128\\" stroke=\\"#3693FF\\" d=\\"M1.692 9.59V3.949a3.949 3.949 0 1 1 7.898 0v5.64M0 9.59h11.282\\" data-follow-stroke=\\"#3693FF\\"/><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" fill-rule=\\"nonzero\\" fill=\\"#3693FF\\" stroke-width=\\"1.128\\" stroke=\\"#3693FF\\" d=\\"M5.641 11.282a1.41 1.41 0 0 0 1.41-1.41V9.59h-2.82v.282c0 .779.631 1.41 1.41 1.41Z\\" data-follow-stroke=\\"#3693FF\\"/></g></g></g>"},"454543":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path stroke-linejoin=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" fill=\\"currentColor\\" d=\\"m12 29 12-12 12 12H12Z\\" data-follow-fill=\\"currentColor\\" data-follow-stroke=\\"currentColor\\"/></g>"},"454545":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path stroke-linejoin=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" fill=\\"currentColor\\" d=\\"M36 19 24 31 12 19h24Z\\" data-follow-fill=\\"currentColor\\" data-follow-stroke=\\"currentColor\\"/></g>"},"454548":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"m19 12 12 12-12 12\\" data-follow-stroke=\\"currentColor\\"/></g>"},"454549":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"M36 18 24 30 12 18\\" data-follow-stroke=\\"currentColor\\"/></g>"},"458971":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path stroke-linejoin=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" fill=\\"currentColor\\" d=\\"m20 12 12 12-12 12V12Z\\" data-follow-fill=\\"currentColor\\" data-follow-stroke=\\"currentColor\\"/></g>"},"465967":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path stroke-linejoin=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" fill=\\"currentColor\\" d=\\"M24 44a19.937 19.937 0 0 0 14.142-5.858A19.937 19.937 0 0 0 44 24a19.938 19.938 0 0 0-5.858-14.142A19.937 19.937 0 0 0 24 4 19.938 19.938 0 0 0 9.858 9.858 19.938 19.938 0 0 0 4 24a19.937 19.937 0 0 0 5.858 14.142A19.938 19.938 0 0 0 24 44Z\\" data-follow-fill=\\"currentColor\\" data-follow-stroke=\\"currentColor\\"/><path fill=\\"#FFF\\" d=\\"M24 37a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z\\" clip-rule=\\"evenodd\\" fill-rule=\\"evenodd\\"/><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"#FFF\\" d=\\"M24 12v16\\"/></g>"},"466609":{"viewBox":"0 0 16 16","content":"<g><g stroke-width=\\"1.125\\" stroke=\\"#FFF\\" fill-rule=\\"nonzero\\" fill=\\"#FFF\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" data-follow-fill=\\"#FFF\\" data-follow-stroke=\\"#FFF\\"><path d=\\"M7.75 6.25a2.625 2.625 0 1 0 0-5.25 2.625 2.625 0 0 0 0 5.25ZM1 14.05v.45h13.5v-.45c0-1.68 0-2.52-.327-3.162a3 3 0 0 0-1.311-1.311C12.22 9.25 11.38 9.25 9.7 9.25H5.8c-1.68 0-2.52 0-3.162.327a3 3 0 0 0-1.311 1.311C1 11.53 1 12.37 1 14.05Z\\"/></g></g>"},"466621":{"viewBox":"0 0 16 16","fill":"currentColor","content":"<g><path d=\\"M7.75 6.25a2.625 2.625 0 1 0 0-5.25 2.625 2.625 0 0 0 0 5.25ZM1 14.05v.45h13.5v-.45c0-1.68 0-2.52-.327-3.162a3 3 0 0 0-1.311-1.311C12.22 9.25 11.38 9.25 9.7 9.25H5.8c-1.68 0-2.52 0-3.162.327a3 3 0 0 0-1.311 1.311C1 11.53 1 12.37 1 14.05Z\\" data-follow-stroke=\\"currentColor\\" data-follow-fill=\\"currentColor\\" stroke-linecap=\\"round\\" stroke-linejoin=\\"round\\" fill=\\"currentColor\\" stroke=\\"currentColor\\" stroke-width=\\"1.125\\"/></g>"},"473644":{"viewBox":"0 0 17 17","content":"<g><path data-follow-fill=\\"#3693FF\\" fill=\\"#3693FF\\" d=\\"M13.917 2.5a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-11a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h11Zm-4 1.329-7 .001a.67.67 0 0 0-.663.571l-.007.099v8a.67.67 0 0 0 .57.663l.1.007h7V3.829Z\\"/></g>"},"546882":{"viewBox":"0 0 12 12","content":"<g><path data-follow-fill=\\"#F77A34\\" d=\\"M10.293 2.134c-.758-.22-2.487-.732-4.12-1.273a.55.55 0 0 0-.346 0c-1.633.54-3.362 1.054-4.12 1.273a.55.55 0 0 0-.395.528v4.192c0 2.41 3.454 3.819 4.688 4.312 1.234-.493 4.688-1.902 4.688-4.312V2.662a.55.55 0 0 0-.395-.528ZM7.998 5.073 5.623 7.449a.368.368 0 0 1-.523 0L4.002 6.353a.37.37 0 0 1 .523-.525l.836.836L7.475 4.55a.37.37 0 1 1 .523.523Z\\" fill=\\"#F77A34\\"/></g>"},"546883":{"viewBox":"0 0 12 12","fill":"currentColor","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><rect data-follow-fill=\\"currentColor\\" fill=\\"currentColor\\" width=\\"12\\" height=\\"12\\" rx=\\"2.25\\"/><path data-follow-fill=\\"currentColor\\" fill-rule=\\"nonzero\\" d=\\"m2.728 6.487 1.878-1.875a.34.34 0 0 1 .263-.112c.112 0 .188.038.263.112.15.15.15.376 0 .525l-1.24 1.238h3.605c.639 0 1.127-.487 1.127-1.125V2.625c0-.225.15-.375.376-.375.225 0 .375.15.375.375V5.25c0 1.05-.826 1.875-1.878 1.875H3.892l1.24 1.238c.15.15.15.374 0 .524a.363.363 0 0 1-.526 0L2.728 7.013c-.037-.038-.075-.076-.075-.113a.416.416 0 0 1 0-.3c0-.037.038-.075.075-.113Z\\" fill=\\"currentColor\\"/></g></g>"},"546884":{"viewBox":"0 0 26 12","fill":"currentColor","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><rect data-follow-fill=\\"currentColor\\" fill=\\"currentColor\\" width=\\"26\\" height=\\"12\\" rx=\\"2.25\\"/><text data-follow-fill=\\"currentColor\\" font-family=\\"PingFangSC-Regular, PingFang SC\\" font-size=\\"9\\" fill=\\"currentColor\\"><tspan x=\\"3.627\\" y=\\"10\\">shift</tspan></text></g></g>"},"566643":{"viewBox":"0 0 16 16","content":"<g><g fill=\\"none\\"><path d=\\"M1 3.714h14v9.429a.866.866 0 0 1-.875.857H1.875A.866.866 0 0 1 1 13.143V3.714Z\\" fill=\\"#FFD94B\\"/><path d=\\"M1.875 2H7l1 1.714H1v-.857C1 2.384 1.392 2 1.875 2Z\\" fill=\\"#F9C433\\"/></g></g>"},"566644":{"viewBox":"0 0 16 16","fill":"currentColor","content":"<g><g data-follow-stroke=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"1.333\\" stroke=\\"currentColor\\" fill-rule=\\"evenodd\\" fill=\\"none\\"><path d=\\"M14.667 6.667v-2A.667.667 0 0 0 14 4H8.333L6.667 2h-4A.667.667 0 0 0 2 2.667v10.666c0 .369.298.667.667.667h5m7.289 1-2-2-2 2\\"/><path d=\\"m11.044 9 2 2 2-2\\"/></g></g>"},"566645":{"viewBox":"0 0 16 16","fill":"currentColor","content":"<g><g data-follow-stroke=\\"currentColor\\" stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"1.333\\" stroke=\\"currentColor\\" fill-rule=\\"evenodd\\" fill=\\"none\\"><path d=\\"M14.667 6.667v-2A.667.667 0 0 0 14 4H8.333L6.667 2h-4A.667.667 0 0 0 2 2.667v10.666c0 .369.298.667.667.667h5m6.289-1-2 2-2-2\\"/><path d=\\"m14.044 10-2-2-2 2\\"/></g></g>"},"566646":{"viewBox":"0 0 12 13","fill":"currentColor","content":"<g><g data-follow-fill=\\"currentColor\\" fill-rule=\\"evenodd\\" fill=\\"currentColor\\" transform=\\"translate(3 2.6)\\"><rect width=\\"6\\" height=\\"1.33\\" rx=\\".665\\"/><rect y=\\"3.3\\" width=\\"6\\" height=\\"1.33\\" rx=\\".665\\"/><rect y=\\"6.6\\" width=\\"6\\" height=\\"1.33\\" rx=\\".665\\"/></g></g>"},"596736":{"viewBox":"0 0 16 16","content":"<g><path d=\\"M14.066 8.206h-9.42v-2.84L.496 8.915l4.15 3.547V9.624h10.13a.71.71 0 0 0 .709-.709V3.467h-1.419v4.739Z\\" fill-rule=\\"nonzero\\" fill=\\"#666\\" data-follow-fill=\\"#666\\"/></g>"},"603545":{"viewBox":"0 0 16 16","fill":"currentColor","content":"<g><g fill=\\"none\\" fill-rule=\\"evenodd\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" fill-rule=\\"nonzero\\" d=\\"M0 0h16v16H0z\\"/><path data-follow-fill=\\"currentColor\\" d=\\"M2.335 2.5h11.33a.835.835 0 1 1 0 1.67H2.335a.835.835 0 1 1 0-1.67Zm0 4.5h11.33a.835.835 0 1 1 0 1.67H2.335a.835.835 0 1 1 0-1.67Zm0 4.5h5.33a.835.835 0 1 1 0 1.67h-5.33a.835.835 0 1 1 0-1.67Z\\" fill=\\"currentColor\\"/></g></g>"},"620341":{"viewBox":"0 0 16 16","content":"<g><g fill-rule=\\"nonzero\\" fill=\\"none\\"><path fill=\\"#FFF\\" fill-opacity=\\".01\\" d=\\"M0 0h16v16H0z\\"/><path fill=\\"#FA6C42\\" d=\\"M2.72.5a.678.678 0 0 0-.504.225A.813.813 0 0 0 2 1.25v13.5c0 .188.072.387.216.525.144.15.324.225.504.225h10.56c.18 0 .372-.075.504-.225A.756.756 0 0 0 14 14.75v-10L9.92.5h-7.2Z\\"/><path d=\\"m5.532 9.5-.63-1.546.584-1.444H4.83l-.252.894-.252-.894H3.67l.567 1.444L3.625 9.5h.655l.299-.953.298.953h.655Zm2.402 0V6.51h-.529L6.86 7.975 6.313 6.51h-.525V9.5h.597V7.946l.319 1.02h.306l.328-1.024V9.5h.596Zm.987 0V7.324H8.36V9.5h.562Zm.063-2.747a.346.346 0 0 0-.344-.344.346.346 0 0 0-.344.344c0 .19.155.345.344.345a.346.346 0 0 0 .344-.345ZM10.786 9.5V7.908c0-.281-.038-.403-.126-.512-.109-.13-.23-.19-.437-.19a.477.477 0 0 0-.214.055.59.59 0 0 0-.164.143V7.24h-.537V9.5h.563V7.917c0-.139.075-.206.176-.206.1 0 .176.067.176.206V9.5h.563Zm1.806 0V6.51h-.563v.865a.587.587 0 0 0-.138-.114.477.477 0 0 0-.214-.054c-.185 0-.311.046-.42.185-.156.193-.156.529-.156.978 0 .45 0 .786.156.979.109.138.235.185.42.185a.477.477 0 0 0 .214-.055c.05-.03.138-.1.164-.143V9.5h.537Zm-.563-.676c0 .071-.02.126-.054.16a.183.183 0 0 1-.122.046.159.159 0 0 1-.147-.089c-.042-.092-.042-.315-.042-.57 0-.257 0-.48.042-.572a.159.159 0 0 1 .147-.088c.042 0 .092.017.122.046.033.034.054.088.054.16v.907Z\\" fill=\\"#FFF\\"/><path fill=\\"#FCD8C4\\" d=\\"M14 4.75h-3.36a.678.678 0 0 1-.504-.225A.734.734 0 0 1 9.92 4V.5L14 4.75Z\\"/></g></g>"},"621990":{"viewBox":"0 0 48 48","fill":"none","content":"<g><path stroke-linejoin=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"M42 6 4 20.138l20 3.87L29.005 44 42 6Z\\" data-follow-stroke=\\"currentColor\\"/><path stroke-linejoin=\\"round\\" stroke-linecap=\\"round\\" stroke-width=\\"4\\" stroke=\\"currentColor\\" d=\\"m24.008 24.008 5.657-5.656\\" data-follow-stroke=\\"currentColor\\"/></g>"}}'
  );
  for (var _k in obj) {
    window.__iconpark__[_k] = obj[_k];
  }
  var nm = {
    down: 31112,
    right: 31114,
    search: 31115,
    remind: 31121,
    "all-application": 31135,
    "add-one": 31136,
    "menu-fold": 31137,
    "menu-unfold": 31138,
    plus: 31149,
    "setting-two": 31150,
    more: 31212,
    "down-one": 31300,
    "close-small": 31302,
    copy: 31304,
    editor: 31306,
    delete: 31307,
    drag: 31557,
    check: 31582,
    issue: 31770,
    redo: 32084,
    "internal-transmission": 34430,
    "external-transmission": 34431,
    "full-screen-two": 34432,
    "off-screen-two": 34433,
    audit: 34617,
    "link-two": 34822,
    download: 34900,
    star: 35816,
    "star-20k9bkld": 35817,
    write: 36261,
    upload: 37127,
    qitawenjian: 37638,
    word: 37639,
    Excelwenjian: 37640,
    PDF: 37641,
    PPT: 37642,
    Txt: 37643,
    yongli: 37644,
    left: 38401,
    help: 38898,
    "close-one": 39856,
    JPG: 39927,
    "zoom-in": 43077,
    paperclip: 44439,
    "paperclip-26lo1cc2": 44440,
    "download-26nmalbp": 44726,
    "upload-26nnkldb": 44727,
    jinjiUrgent: 44996,
    attention: 57905,
    wenjianlianjie: 60372,
    "all-application-2d92e68k": 60460,
    "list-view": 60464,
    gengduo: 60811,
    up: 60900,
    "expand-text-input": 60921,
    "collapse-text-input": 60922,
    "up-small": 60927,
    "down-small": 60928,
    "help-2eaakgin": 62283,
    "close-one-2fmjlcjj": 64718,
    "to-left": 72398,
    "to-right": 72400,
    "check-one": 76393,
    "reduce-one": 76394,
    "sort-amount-down": 77021,
    find: 77244,
    "attention-2jbb388d": 77269,
    tixing: 77297,
    "attention-2jidg7o6": 77464,
    banben: 80166,
    "align-text-left-one": 86260,
    renwu: 87901,
    shaixuan: 87902,
    xuqiu: 87903,
    quexian: 87904,
    tishi: 87905,
    paixu: 90491,
    tuijian: 94434,
    bianzu68: 94997,
    bianzu69: 94998,
    bianzu67: 94999,
    re: 95027,
    you: 95143,
    zuo: 95144,
    shanchu: 95579,
    fengxian: 98755,
    diedai1: 98763,
    "fengxian-37kaf4gn": 100734,
    "upload-one": 100736,
    pingshen: 100749,
    "doc-detail": 103160,
    "data-file": 103161,
    send: 103199,
    "pie-three": 108308,
    calendar: 108309,
    biangeng: 116059,
    "fengxian-3h56ddpd": 116060,
    jiahao: 116891,
    "smiling-face-3he7dem8": 116928,
    "emotion-unhappy-3he7haj2": 116931,
    "neutral-face-3he81a1j": 116936,
    chanpinicon: 120047,
    xiangmuicon: 120048,
    xiangmu: 125790,
    "download-two": 133540,
    "check-3np77mmd": 133571,
    "adjacent-item": 135944,
    "go-start": 137895,
    "go-end": 137896,
    "to-left-41ibg8oj": 139867,
    "to-right-41ibgh14": 139868,
    zixuqiu: 141135,
    jindujilu: 141176,
    pinglun: 141177,
    quanzhong: 141178,
    shangchuantupian: 141179,
    lishibanben: 141180,
    tuandui: 141181,
    kaisuo: 141182,
    quanxianshezhi: 141183,
    biaoqing: 141184,
    fenxiang: 141185,
    "chart-histogram": 141253,
    "Txt-4302a83k": 141407,
    "JPG-4302a842": 141408,
    "word-4302a83i": 141409,
    "PDF-4302a83i": 141410,
    "PPT-4302a82i": 141411,
    "wenjianlianjie-4302a849": 141412,
    "qitawenjian-4302a83i": 141413,
    zip: 141414,
    "Excelwenjian-4302a873": 141415,
    document: 141417,
    SVG: 141418,
    fabuyongdao: 146716,
    duiqishangji: 149187,
    beiduiqi: 149188,
    huifu: 168975,
    dianzan: 168976,
    dianzanweixuanzhong: 168977,
    tips: 171533,
    comment: 171534,
    history: 171535,
    mubiaoliuzhuan: 193287,
    "chart-line": 193323,
    zuzhijiagou: 199049,
    shanchuyidongduan: 201785,
    zhiding: 210081,
    quxiaozhiding: 210082,
    zhanbi: 210635,
    pingfen: 210636,
    yidianzan: 219025,
    bunengxuan: 219026,
    gouxuan: 219027,
    eyes: 219962,
    "right-branch": 220895,
    "assembly-line": 223220,
    "chart-graph": 224429,
    loading: 226619,
    rili: 234676,
    "mindmap-list": 279264,
    jiantoufanyexia: 291587,
    jiantoufanyeshang: 291588,
    "biangeng-5ip0ckfj": 295729,
    "fengxian-5ip0ckf2": 295730,
    "xuqiu-5ip0ckde": 295731,
    "xuqiu-5ip0ckh1": 295732,
    guanlian: 358989,
    sousuo: 375984,
    "xuqiu-5mam41oe": 375985,
    "paixu-5mam41jp": 375986,
    "shaixuan-5mam41op": 375987,
    "renwu-5mam41nf": 375989,
    xinzeng: 387996,
    daoru: 388499,
    "xuqiu-5nj1k03c": 408147,
    "fengxian-5nj1k04c": 408148,
    jiankang: 408149,
    "biangeng-5nj1k05m": 408150,
    xiangmushijian: 408151,
    yichang: 408153,
    "renwu-5nj1k04e": 408154,
    xiangmufuzeren: 408155,
    gongzuojihua: 409691,
    "to-top": 411538,
    "mindmap-list-5npfp8pd": 411540,
    gongshirili: 424894,
    fangda: 424895,
    "gongshirili-5oeiak8o": 427317,
    "fangda-5oeiakai": 427318,
    xiaoxitongzhi: 453634,
    "up-one": 454543,
    "down-one-61mcbjhm": 454545,
    "right-61mcd27l": 454548,
    "down-61mce9il": 454549,
    "right-one": 458971,
    "attention-62bn4jn9": 465967,
    wode: 466609,
    wodehui: 466621,
    zhankaiyoucexiangqing: 473644,
    jiance: 546882,
    enter: 546883,
    shift: 546884,
    fenzu: 566643,
    shouqi: 566644,
    zhankai: 566645,
    tuozhuai: 566646,
    huiche: 596736,
    xinxi: 603545,
    Xmindwenjian: 620341,
    "send-one": 621990,
  };
  for (var _i in nm) {
    window.__iconpark__[_i] = obj[nm[_i]];
  }
})();
"object" != typeof globalThis &&
  (Object.prototype.__defineGetter__("__magic__", function () {
    return this;
  }),
  (__magic__.globalThis = __magic__),
  delete Object.prototype.__magic__);
(() => {
  "use strict";
  var t = {
      816: (t, e, i) => {
        var s, r, o, n;
        i.d(e, {
          Vm: () => z,
          dy: () => P,
          Jb: () => x,
          Ld: () => $,
          sY: () => T,
          YP: () => A,
        });
        const l = globalThis.trustedTypes,
          a = l ? l.createPolicy("lit-html", { createHTML: (t) => t }) : void 0,
          h = `lit$${(Math.random() + "").slice(9)}$`,
          c = "?" + h,
          d = `<${c}>`,
          u = document,
          p = (t = "") => u.createComment(t),
          v = (t) =>
            null === t || ("object" != typeof t && "function" != typeof t),
          f = Array.isArray,
          y = (t) => {
            var e;
            return (
              f(t) ||
              "function" ==
                typeof (null === (e = t) || void 0 === e
                  ? void 0
                  : e[Symbol.iterator])
            );
          },
          m = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,
          g = /-->/g,
          b = />/g,
          S =
            />|[ 	\n\r](?:([^\s"'>=/]+)([ 	\n\r]*=[ 	\n\r]*(?:[^ 	\n\r"'`<>=]|("|')|))|$)/g,
          w = /'/g,
          k = /"/g,
          E = /^(?:script|style|textarea)$/i,
          C =
            (t) =>
            (e, ...i) => ({ _$litType$: t, strings: e, values: i }),
          P = C(1),
          A = C(2),
          x = Symbol.for("lit-noChange"),
          $ = Symbol.for("lit-nothing"),
          O = new WeakMap(),
          T = (t, e, i) => {
            var s, r;
            const o =
              null !== (s = null == i ? void 0 : i.renderBefore) && void 0 !== s
                ? s
                : e;
            let n = o._$litPart$;
            if (void 0 === n) {
              const t =
                null !== (r = null == i ? void 0 : i.renderBefore) &&
                void 0 !== r
                  ? r
                  : null;
              o._$litPart$ = n = new H(e.insertBefore(p(), t), t, void 0, i);
            }
            return n.I(t), n;
          },
          R = u.createTreeWalker(u, 129, null, !1),
          _ = (t, e) => {
            const i = t.length - 1,
              s = [];
            let r,
              o = 2 === e ? "<svg>" : "",
              n = m;
            for (let e = 0; e < i; e++) {
              const i = t[e];
              let l,
                a,
                c = -1,
                u = 0;
              for (
                ;
                u < i.length &&
                ((n.lastIndex = u), (a = n.exec(i)), null !== a);

              )
                (u = n.lastIndex),
                  n === m
                    ? "!--" === a[1]
                      ? (n = g)
                      : void 0 !== a[1]
                      ? (n = b)
                      : void 0 !== a[2]
                      ? (E.test(a[2]) && (r = RegExp("</" + a[2], "g")),
                        (n = S))
                      : void 0 !== a[3] && (n = S)
                    : n === S
                    ? ">" === a[0]
                      ? ((n = null != r ? r : m), (c = -1))
                      : void 0 === a[1]
                      ? (c = -2)
                      : ((c = n.lastIndex - a[2].length),
                        (l = a[1]),
                        (n = void 0 === a[3] ? S : '"' === a[3] ? k : w))
                    : n === k || n === w
                    ? (n = S)
                    : n === g || n === b
                    ? (n = m)
                    : ((n = S), (r = void 0));
              const p = n === S && t[e + 1].startsWith("/>") ? " " : "";
              o +=
                n === m
                  ? i + d
                  : c >= 0
                  ? (s.push(l), i.slice(0, c) + "$lit$" + i.slice(c) + h + p)
                  : i + h + (-2 === c ? (s.push(void 0), e) : p);
            }
            const l = o + (t[i] || "<?>") + (2 === e ? "</svg>" : "");
            return [void 0 !== a ? a.createHTML(l) : l, s];
          };
        class N {
          constructor({ strings: t, _$litType$: e }, i) {
            let s;
            this.parts = [];
            let r = 0,
              o = 0;
            const n = t.length - 1,
              a = this.parts,
              [d, u] = _(t, e);
            if (
              ((this.el = N.createElement(d, i)),
              (R.currentNode = this.el.content),
              2 === e)
            ) {
              const t = this.el.content,
                e = t.firstChild;
              e.remove(), t.append(...e.childNodes);
            }
            for (; null !== (s = R.nextNode()) && a.length < n; ) {
              if (1 === s.nodeType) {
                if (s.hasAttributes()) {
                  const t = [];
                  for (const e of s.getAttributeNames())
                    if (e.endsWith("$lit$") || e.startsWith(h)) {
                      const i = u[o++];
                      if ((t.push(e), void 0 !== i)) {
                        const t = s
                            .getAttribute(i.toLowerCase() + "$lit$")
                            .split(h),
                          e = /([.?@])?(.*)/.exec(i);
                        a.push({
                          type: 1,
                          index: r,
                          name: e[2],
                          strings: t,
                          ctor:
                            "." === e[1]
                              ? I
                              : "?" === e[1]
                              ? j
                              : "@" === e[1]
                              ? B
                              : M,
                        });
                      } else a.push({ type: 6, index: r });
                    }
                  for (const e of t) s.removeAttribute(e);
                }
                if (E.test(s.tagName)) {
                  const t = s.textContent.split(h),
                    e = t.length - 1;
                  if (e > 0) {
                    s.textContent = l ? l.emptyScript : "";
                    for (let i = 0; i < e; i++)
                      s.append(t[i], p()),
                        R.nextNode(),
                        a.push({ type: 2, index: ++r });
                    s.append(t[e], p());
                  }
                }
              } else if (8 === s.nodeType)
                if (s.data === c) a.push({ type: 2, index: r });
                else {
                  let t = -1;
                  for (; -1 !== (t = s.data.indexOf(h, t + 1)); )
                    a.push({ type: 7, index: r }), (t += h.length - 1);
                }
              r++;
            }
          }
          static createElement(t, e) {
            const i = u.createElement("template");
            return (i.innerHTML = t), i;
          }
        }
        function U(t, e, i = t, s) {
          var r, o, n, l;
          if (e === x) return e;
          let a =
            void 0 !== s
              ? null === (r = i.Σi) || void 0 === r
                ? void 0
                : r[s]
              : i.Σo;
          const h = v(e) ? void 0 : e._$litDirective$;
          return (
            (null == a ? void 0 : a.constructor) !== h &&
              (null === (o = null == a ? void 0 : a.O) ||
                void 0 === o ||
                o.call(a, !1),
              void 0 === h ? (a = void 0) : ((a = new h(t)), a.T(t, i, s)),
              void 0 !== s
                ? ((null !== (n = (l = i).Σi) && void 0 !== n
                    ? n
                    : (l.Σi = []))[s] = a)
                : (i.Σo = a)),
            void 0 !== a && (e = U(t, a.S(t, e.values), a, s)),
            e
          );
        }
        class L {
          constructor(t, e) {
            (this.l = []), (this.N = void 0), (this.D = t), (this.M = e);
          }
          u(t) {
            var e;
            const {
                el: { content: i },
                parts: s,
              } = this.D,
              r = (
                null !== (e = null == t ? void 0 : t.creationScope) &&
                void 0 !== e
                  ? e
                  : u
              ).importNode(i, !0);
            R.currentNode = r;
            let o = R.nextNode(),
              n = 0,
              l = 0,
              a = s[0];
            for (; void 0 !== a; ) {
              if (n === a.index) {
                let e;
                2 === a.type
                  ? (e = new H(o, o.nextSibling, this, t))
                  : 1 === a.type
                  ? (e = new a.ctor(o, a.name, a.strings, this, t))
                  : 6 === a.type && (e = new V(o, this, t)),
                  this.l.push(e),
                  (a = s[++l]);
              }
              n !== (null == a ? void 0 : a.index) && ((o = R.nextNode()), n++);
            }
            return r;
          }
          v(t) {
            let e = 0;
            for (const i of this.l)
              void 0 !== i &&
                (void 0 !== i.strings
                  ? (i.I(t, i, e), (e += i.strings.length - 2))
                  : i.I(t[e])),
                e++;
          }
        }
        class H {
          constructor(t, e, i, s) {
            (this.type = 2),
              (this.N = void 0),
              (this.A = t),
              (this.B = e),
              (this.M = i),
              (this.options = s);
          }
          setConnected(t) {
            var e;
            null === (e = this.P) || void 0 === e || e.call(this, t);
          }
          get parentNode() {
            return this.A.parentNode;
          }
          get startNode() {
            return this.A;
          }
          get endNode() {
            return this.B;
          }
          I(t, e = this) {
            (t = U(this, t, e)),
              v(t)
                ? t === $ || null == t || "" === t
                  ? (this.H !== $ && this.R(), (this.H = $))
                  : t !== this.H && t !== x && this.m(t)
                : void 0 !== t._$litType$
                ? this._(t)
                : void 0 !== t.nodeType
                ? this.$(t)
                : y(t)
                ? this.g(t)
                : this.m(t);
          }
          k(t, e = this.B) {
            return this.A.parentNode.insertBefore(t, e);
          }
          $(t) {
            this.H !== t && (this.R(), (this.H = this.k(t)));
          }
          m(t) {
            const e = this.A.nextSibling;
            null !== e &&
            3 === e.nodeType &&
            (null === this.B
              ? null === e.nextSibling
              : e === this.B.previousSibling)
              ? (e.data = t)
              : this.$(u.createTextNode(t)),
              (this.H = t);
          }
          _(t) {
            var e;
            const { values: i, _$litType$: s } = t,
              r =
                "number" == typeof s
                  ? this.C(t)
                  : (void 0 === s.el &&
                      (s.el = N.createElement(s.h, this.options)),
                    s);
            if ((null === (e = this.H) || void 0 === e ? void 0 : e.D) === r)
              this.H.v(i);
            else {
              const t = new L(r, this),
                e = t.u(this.options);
              t.v(i), this.$(e), (this.H = t);
            }
          }
          C(t) {
            let e = O.get(t.strings);
            return void 0 === e && O.set(t.strings, (e = new N(t))), e;
          }
          g(t) {
            f(this.H) || ((this.H = []), this.R());
            const e = this.H;
            let i,
              s = 0;
            for (const r of t)
              s === e.length
                ? e.push(
                    (i = new H(this.k(p()), this.k(p()), this, this.options))
                  )
                : (i = e[s]),
                i.I(r),
                s++;
            s < e.length && (this.R(i && i.B.nextSibling, s), (e.length = s));
          }
          R(t = this.A.nextSibling, e) {
            var i;
            for (
              null === (i = this.P) || void 0 === i || i.call(this, !1, !0, e);
              t && t !== this.B;

            ) {
              const e = t.nextSibling;
              t.remove(), (t = e);
            }
          }
        }
        class M {
          constructor(t, e, i, s, r) {
            (this.type = 1),
              (this.H = $),
              (this.N = void 0),
              (this.V = void 0),
              (this.element = t),
              (this.name = e),
              (this.M = s),
              (this.options = r),
              i.length > 2 || "" !== i[0] || "" !== i[1]
                ? ((this.H = Array(i.length - 1).fill($)), (this.strings = i))
                : (this.H = $);
          }
          get tagName() {
            return this.element.tagName;
          }
          I(t, e = this, i, s) {
            const r = this.strings;
            let o = !1;
            if (void 0 === r)
              (t = U(this, t, e, 0)),
                (o = !v(t) || (t !== this.H && t !== x)),
                o && (this.H = t);
            else {
              const s = t;
              let n, l;
              for (t = r[0], n = 0; n < r.length - 1; n++)
                (l = U(this, s[i + n], e, n)),
                  l === x && (l = this.H[n]),
                  o || (o = !v(l) || l !== this.H[n]),
                  l === $
                    ? (t = $)
                    : t !== $ && (t += (null != l ? l : "") + r[n + 1]),
                  (this.H[n] = l);
            }
            o && !s && this.W(t);
          }
          W(t) {
            t === $
              ? this.element.removeAttribute(this.name)
              : this.element.setAttribute(this.name, null != t ? t : "");
          }
        }
        class I extends M {
          constructor() {
            super(...arguments), (this.type = 3);
          }
          W(t) {
            this.element[this.name] = t === $ ? void 0 : t;
          }
        }
        class j extends M {
          constructor() {
            super(...arguments), (this.type = 4);
          }
          W(t) {
            t && t !== $
              ? this.element.setAttribute(this.name, "")
              : this.element.removeAttribute(this.name);
          }
        }
        class B extends M {
          constructor() {
            super(...arguments), (this.type = 5);
          }
          I(t, e = this) {
            var i;
            if (
              (t = null !== (i = U(this, t, e, 0)) && void 0 !== i ? i : $) ===
              x
            )
              return;
            const s = this.H,
              r =
                (t === $ && s !== $) ||
                t.capture !== s.capture ||
                t.once !== s.once ||
                t.passive !== s.passive,
              o = t !== $ && (s === $ || r);
            r && this.element.removeEventListener(this.name, this, s),
              o && this.element.addEventListener(this.name, this, t),
              (this.H = t);
          }
          handleEvent(t) {
            var e, i;
            "function" == typeof this.H
              ? this.H.call(
                  null !==
                    (i =
                      null === (e = this.options) || void 0 === e
                        ? void 0
                        : e.host) && void 0 !== i
                    ? i
                    : this.element,
                  t
                )
              : this.H.handleEvent(t);
          }
        }
        class V {
          constructor(t, e, i) {
            (this.element = t),
              (this.type = 6),
              (this.N = void 0),
              (this.V = void 0),
              (this.M = e),
              (this.options = i);
          }
          I(t) {
            U(this, t);
          }
        }
        const z = {
          Z: "$lit$",
          U: h,
          Y: c,
          q: 1,
          X: _,
          tt: L,
          it: y,
          st: U,
          et: H,
          ot: M,
          nt: j,
          rt: B,
          lt: I,
          ht: V,
        };
        null === (r = (s = globalThis).litHtmlPlatformSupport) ||
          void 0 === r ||
          r.call(s, N, H),
          (null !== (o = (n = globalThis).litHtmlVersions) && void 0 !== o
            ? o
            : (n.litHtmlVersions = [])
          ).push("2.0.0-rc.2");
      },
      26: (t, e, i) => {
        i.r(e),
          i.d(e, {
            customElement: () => s,
            eventOptions: () => a,
            property: () => o,
            query: () => h,
            queryAll: () => c,
            queryAssignedNodes: () => v,
            queryAsync: () => d,
            state: () => n,
          });
        const s = (t) => (e) =>
            "function" == typeof e
              ? ((t, e) => (window.customElements.define(t, e), e))(t, e)
              : ((t, e) => {
                  const { kind: i, elements: s } = e;
                  return {
                    kind: i,
                    elements: s,
                    finisher(e) {
                      window.customElements.define(t, e);
                    },
                  };
                })(t, e),
          r = (t, e) =>
            "method" === e.kind && e.descriptor && !("value" in e.descriptor)
              ? {
                  ...e,
                  finisher(i) {
                    i.createProperty(e.key, t);
                  },
                }
              : {
                  kind: "field",
                  key: Symbol(),
                  placement: "own",
                  descriptor: {},
                  originalKey: e.key,
                  initializer() {
                    "function" == typeof e.initializer &&
                      (this[e.key] = e.initializer.call(this));
                  },
                  finisher(i) {
                    i.createProperty(e.key, t);
                  },
                };
        function o(t) {
          return (e, i) =>
            void 0 !== i
              ? ((t, e, i) => {
                  e.constructor.createProperty(i, t);
                })(t, e, i)
              : r(t, e);
        }
        function n(t) {
          return o({ ...t, state: !0, attribute: !1 });
        }
        const l =
          ({ finisher: t, descriptor: e }) =>
          (i, s) => {
            var r;
            if (void 0 === s) {
              const s =
                  null !== (r = i.originalKey) && void 0 !== r ? r : i.key,
                o =
                  null != e
                    ? {
                        kind: "method",
                        placement: "prototype",
                        key: s,
                        descriptor: e(i.key),
                      }
                    : { ...i, key: s };
              return (
                null != t &&
                  (o.finisher = function (e) {
                    t(e, s);
                  }),
                o
              );
            }
            {
              const r = i.constructor;
              void 0 !== e && Object.defineProperty(i, s, e(s)),
                null == t || t(r, s);
            }
          };
        function a(t) {
          return l({
            finisher: (e, i) => {
              Object.assign(e.prototype[i], t);
            },
          });
        }
        function h(t, e) {
          return l({
            descriptor: (i) => {
              const s = {
                get() {
                  var e;
                  return null === (e = this.renderRoot) || void 0 === e
                    ? void 0
                    : e.querySelector(t);
                },
                enumerable: !0,
                configurable: !0,
              };
              if (e) {
                const e = "symbol" == typeof i ? Symbol() : "__" + i;
                s.get = function () {
                  var i;
                  return (
                    void 0 === this[e] &&
                      (this[e] =
                        null === (i = this.renderRoot) || void 0 === i
                          ? void 0
                          : i.querySelector(t)),
                    this[e]
                  );
                };
              }
              return s;
            },
          });
        }
        function c(t) {
          return l({
            descriptor: (e) => ({
              get() {
                var e;
                return null === (e = this.renderRoot) || void 0 === e
                  ? void 0
                  : e.querySelectorAll(t);
              },
              enumerable: !0,
              configurable: !0,
            }),
          });
        }
        function d(t) {
          return l({
            descriptor: (e) => ({
              async get() {
                var e;
                return (
                  await this.updateComplete,
                  null === (e = this.renderRoot) || void 0 === e
                    ? void 0
                    : e.querySelector(t)
                );
              },
              enumerable: !0,
              configurable: !0,
            }),
          });
        }
        const u = Element.prototype,
          p = u.msMatchesSelector || u.webkitMatchesSelector;
        function v(t = "", e = !1, i = "") {
          return l({
            descriptor: (s) => ({
              get() {
                var s, r;
                const o = "slot" + (t ? `[name=${t}]` : ":not([name])");
                let n =
                  null ===
                    (r =
                      null === (s = this.renderRoot) || void 0 === s
                        ? void 0
                        : s.querySelector(o)) || void 0 === r
                    ? void 0
                    : r.assignedNodes({ flatten: e });
                return (
                  n &&
                    i &&
                    (n = n.filter(
                      (t) =>
                        t.nodeType === Node.ELEMENT_NODE &&
                        (t.matches ? t.matches(i) : p.call(t, i))
                    )),
                  n
                );
              },
              enumerable: !0,
              configurable: !0,
            }),
          });
        }
      },
      23: (t, e, i) => {
        i.r(e), i.d(e, { unsafeSVG: () => l });
        const s =
          (t) =>
          (...e) => ({ _$litDirective$: t, values: e });
        var r = i(816);
        class o extends class {
          constructor(t) {}
          T(t, e, i) {
            (this.Σdt = t), (this.M = e), (this.Σct = i);
          }
          S(t, e) {
            return this.update(t, e);
          }
          update(t, e) {
            return this.render(...e);
          }
        } {
          constructor(t) {
            if ((super(t), (this.vt = r.Ld), 2 !== t.type))
              throw Error(
                this.constructor.directiveName +
                  "() can only be used in child bindings"
              );
          }
          render(t) {
            if (t === r.Ld) return (this.Vt = void 0), (this.vt = t);
            if (t === r.Jb) return t;
            if ("string" != typeof t)
              throw Error(
                this.constructor.directiveName +
                  "() called with a non-string value"
              );
            if (t === this.vt) return this.Vt;
            this.vt = t;
            const e = [t];
            return (
              (e.raw = e),
              (this.Vt = {
                _$litType$: this.constructor.resultType,
                strings: e,
                values: [],
              })
            );
          }
        }
        (o.directiveName = "unsafeHTML"), (o.resultType = 1), s(o);
        class n extends o {}
        (n.directiveName = "unsafeSVG"), (n.resultType = 2);
        const l = s(n);
      },
      249: (t, e, i) => {
        i.r(e),
          i.d(e, {
            CSSResult: () => n,
            LitElement: () => x,
            ReactiveElement: () => b,
            UpdatingElement: () => A,
            _Σ: () => s.Vm,
            _Φ: () => $,
            adoptStyles: () => c,
            css: () => h,
            defaultConverter: () => y,
            getCompatibleStyle: () => d,
            html: () => s.dy,
            noChange: () => s.Jb,
            notEqual: () => m,
            nothing: () => s.Ld,
            render: () => s.sY,
            supportsAdoptingStyleSheets: () => r,
            svg: () => s.YP,
            unsafeCSS: () => l,
          });
        var s = i(816);
        const r =
            window.ShadowRoot &&
            (void 0 === window.ShadyCSS || window.ShadyCSS.nativeShadow) &&
            "adoptedStyleSheets" in Document.prototype &&
            "replace" in CSSStyleSheet.prototype,
          o = Symbol();
        class n {
          constructor(t, e) {
            if (e !== o)
              throw Error(
                "CSSResult is not constructable. Use `unsafeCSS` or `css` instead."
              );
            this.cssText = t;
          }
          get styleSheet() {
            return (
              r &&
                void 0 === this.t &&
                ((this.t = new CSSStyleSheet()),
                this.t.replaceSync(this.cssText)),
              this.t
            );
          }
          toString() {
            return this.cssText;
          }
        }
        const l = (t) => new n(t + "", o),
          a = new Map(),
          h = (t, ...e) => {
            const i = e.reduce(
              (e, i, s) =>
                e +
                ((t) => {
                  if (t instanceof n) return t.cssText;
                  if ("number" == typeof t) return t;
                  throw Error(
                    `Value passed to 'css' function must be a 'css' function result: ${t}. Use 'unsafeCSS' to pass non-literal values, but\n            take care to ensure page security.`
                  );
                })(i) +
                t[s + 1],
              t[0]
            );
            let s = a.get(i);
            return void 0 === s && a.set(i, (s = new n(i, o))), s;
          },
          c = (t, e) => {
            r
              ? (t.adoptedStyleSheets = e.map((t) =>
                  t instanceof CSSStyleSheet ? t : t.styleSheet
                ))
              : e.forEach((e) => {
                  const i = document.createElement("style");
                  (i.textContent = e.cssText), t.appendChild(i);
                });
          },
          d = r
            ? (t) => t
            : (t) =>
                t instanceof CSSStyleSheet
                  ? ((t) => {
                      let e = "";
                      for (const i of t.cssRules) e += i.cssText;
                      return l(e);
                    })(t)
                  : t;
        var u, p, v, f;
        const y = {
            toAttribute(t, e) {
              switch (e) {
                case Boolean:
                  t = t ? "" : null;
                  break;
                case Object:
                case Array:
                  t = null == t ? t : JSON.stringify(t);
              }
              return t;
            },
            fromAttribute(t, e) {
              let i = t;
              switch (e) {
                case Boolean:
                  i = null !== t;
                  break;
                case Number:
                  i = null === t ? null : Number(t);
                  break;
                case Object:
                case Array:
                  try {
                    i = JSON.parse(t);
                  } catch (t) {
                    i = null;
                  }
              }
              return i;
            },
          },
          m = (t, e) => e !== t && (e == e || t == t),
          g = {
            attribute: !0,
            type: String,
            converter: y,
            reflect: !1,
            hasChanged: m,
          };
        class b extends HTMLElement {
          constructor() {
            super(),
              (this.Πi = new Map()),
              (this.Πo = void 0),
              (this.Πl = void 0),
              (this.isUpdatePending = !1),
              (this.hasUpdated = !1),
              (this.Πh = null),
              this.u();
          }
          static addInitializer(t) {
            var e;
            (null !== (e = this.v) && void 0 !== e) || (this.v = []),
              this.v.push(t);
          }
          static get observedAttributes() {
            this.finalize();
            const t = [];
            return (
              this.elementProperties.forEach((e, i) => {
                const s = this.Πp(i, e);
                void 0 !== s && (this.Πm.set(s, i), t.push(s));
              }),
              t
            );
          }
          static createProperty(t, e = g) {
            if (
              (e.state && (e.attribute = !1),
              this.finalize(),
              this.elementProperties.set(t, e),
              !e.noAccessor && !this.prototype.hasOwnProperty(t))
            ) {
              const i = "symbol" == typeof t ? Symbol() : "__" + t,
                s = this.getPropertyDescriptor(t, i, e);
              void 0 !== s && Object.defineProperty(this.prototype, t, s);
            }
          }
          static getPropertyDescriptor(t, e, i) {
            return {
              get() {
                return this[e];
              },
              set(s) {
                const r = this[t];
                (this[e] = s), this.requestUpdate(t, r, i);
              },
              configurable: !0,
              enumerable: !0,
            };
          }
          static getPropertyOptions(t) {
            return this.elementProperties.get(t) || g;
          }
          static finalize() {
            if (this.hasOwnProperty("finalized")) return !1;
            this.finalized = !0;
            const t = Object.getPrototypeOf(this);
            if (
              (t.finalize(),
              (this.elementProperties = new Map(t.elementProperties)),
              (this.Πm = new Map()),
              this.hasOwnProperty("properties"))
            ) {
              const t = this.properties,
                e = [
                  ...Object.getOwnPropertyNames(t),
                  ...Object.getOwnPropertySymbols(t),
                ];
              for (const i of e) this.createProperty(i, t[i]);
            }
            return (this.elementStyles = this.finalizeStyles(this.styles)), !0;
          }
          static finalizeStyles(t) {
            const e = [];
            if (Array.isArray(t)) {
              const i = new Set(t.flat(1 / 0).reverse());
              for (const t of i) e.unshift(d(t));
            } else void 0 !== t && e.push(d(t));
            return e;
          }
          static Πp(t, e) {
            const i = e.attribute;
            return !1 === i
              ? void 0
              : "string" == typeof i
              ? i
              : "string" == typeof t
              ? t.toLowerCase()
              : void 0;
          }
          u() {
            var t;
            (this.Πg = new Promise((t) => (this.enableUpdating = t))),
              (this.L = new Map()),
              this.Π_(),
              this.requestUpdate(),
              null === (t = this.constructor.v) ||
                void 0 === t ||
                t.forEach((t) => t(this));
          }
          addController(t) {
            var e, i;
            (null !== (e = this.ΠU) && void 0 !== e ? e : (this.ΠU = [])).push(
              t
            ),
              void 0 !== this.renderRoot &&
                this.isConnected &&
                (null === (i = t.hostConnected) || void 0 === i || i.call(t));
          }
          removeController(t) {
            var e;
            null === (e = this.ΠU) ||
              void 0 === e ||
              e.splice(this.ΠU.indexOf(t) >>> 0, 1);
          }
          Π_() {
            this.constructor.elementProperties.forEach((t, e) => {
              this.hasOwnProperty(e) &&
                (this.Πi.set(e, this[e]), delete this[e]);
            });
          }
          createRenderRoot() {
            var t;
            const e =
              null !== (t = this.shadowRoot) && void 0 !== t
                ? t
                : this.attachShadow(this.constructor.shadowRootOptions);
            return c(e, this.constructor.elementStyles), e;
          }
          connectedCallback() {
            var t;
            void 0 === this.renderRoot &&
              (this.renderRoot = this.createRenderRoot()),
              this.enableUpdating(!0),
              null === (t = this.ΠU) ||
                void 0 === t ||
                t.forEach((t) => {
                  var e;
                  return null === (e = t.hostConnected) || void 0 === e
                    ? void 0
                    : e.call(t);
                }),
              this.Πl && (this.Πl(), (this.Πo = this.Πl = void 0));
          }
          enableUpdating(t) {}
          disconnectedCallback() {
            var t;
            null === (t = this.ΠU) ||
              void 0 === t ||
              t.forEach((t) => {
                var e;
                return null === (e = t.hostDisconnected) || void 0 === e
                  ? void 0
                  : e.call(t);
              }),
              (this.Πo = new Promise((t) => (this.Πl = t)));
          }
          attributeChangedCallback(t, e, i) {
            this.K(t, i);
          }
          Πj(t, e, i = g) {
            var s, r;
            const o = this.constructor.Πp(t, i);
            if (void 0 !== o && !0 === i.reflect) {
              const n = (
                null !==
                  (r =
                    null === (s = i.converter) || void 0 === s
                      ? void 0
                      : s.toAttribute) && void 0 !== r
                  ? r
                  : y.toAttribute
              )(e, i.type);
              (this.Πh = t),
                null == n ? this.removeAttribute(o) : this.setAttribute(o, n),
                (this.Πh = null);
            }
          }
          K(t, e) {
            var i, s, r;
            const o = this.constructor,
              n = o.Πm.get(t);
            if (void 0 !== n && this.Πh !== n) {
              const t = o.getPropertyOptions(n),
                l = t.converter,
                a =
                  null !==
                    (r =
                      null !==
                        (s =
                          null === (i = l) || void 0 === i
                            ? void 0
                            : i.fromAttribute) && void 0 !== s
                        ? s
                        : "function" == typeof l
                        ? l
                        : null) && void 0 !== r
                    ? r
                    : y.fromAttribute;
              (this.Πh = n), (this[n] = a(e, t.type)), (this.Πh = null);
            }
          }
          requestUpdate(t, e, i) {
            let s = !0;
            void 0 !== t &&
              ((
                (i = i || this.constructor.getPropertyOptions(t)).hasChanged ||
                m
              )(this[t], e)
                ? (this.L.has(t) || this.L.set(t, e),
                  !0 === i.reflect &&
                    this.Πh !== t &&
                    (void 0 === this.Πk && (this.Πk = new Map()),
                    this.Πk.set(t, i)))
                : (s = !1)),
              !this.isUpdatePending && s && (this.Πg = this.Πq());
          }
          async Πq() {
            this.isUpdatePending = !0;
            try {
              for (await this.Πg; this.Πo; ) await this.Πo;
            } catch (t) {
              Promise.reject(t);
            }
            const t = this.performUpdate();
            return null != t && (await t), !this.isUpdatePending;
          }
          performUpdate() {
            var t;
            if (!this.isUpdatePending) return;
            this.hasUpdated,
              this.Πi &&
                (this.Πi.forEach((t, e) => (this[e] = t)), (this.Πi = void 0));
            let e = !1;
            const i = this.L;
            try {
              (e = this.shouldUpdate(i)),
                e
                  ? (this.willUpdate(i),
                    null === (t = this.ΠU) ||
                      void 0 === t ||
                      t.forEach((t) => {
                        var e;
                        return null === (e = t.hostUpdate) || void 0 === e
                          ? void 0
                          : e.call(t);
                      }),
                    this.update(i))
                  : this.Π$();
            } catch (t) {
              throw ((e = !1), this.Π$(), t);
            }
            e && this.E(i);
          }
          willUpdate(t) {}
          E(t) {
            var e;
            null === (e = this.ΠU) ||
              void 0 === e ||
              e.forEach((t) => {
                var e;
                return null === (e = t.hostUpdated) || void 0 === e
                  ? void 0
                  : e.call(t);
              }),
              this.hasUpdated || ((this.hasUpdated = !0), this.firstUpdated(t)),
              this.updated(t);
          }
          Π$() {
            (this.L = new Map()), (this.isUpdatePending = !1);
          }
          get updateComplete() {
            return this.getUpdateComplete();
          }
          getUpdateComplete() {
            return this.Πg;
          }
          shouldUpdate(t) {
            return !0;
          }
          update(t) {
            void 0 !== this.Πk &&
              (this.Πk.forEach((t, e) => this.Πj(e, this[e], t)),
              (this.Πk = void 0)),
              this.Π$();
          }
          updated(t) {}
          firstUpdated(t) {}
        }
        var S, w, k, E, C, P;
        (b.finalized = !0),
          (b.shadowRootOptions = { mode: "open" }),
          null === (p = (u = globalThis).reactiveElementPlatformSupport) ||
            void 0 === p ||
            p.call(u, { ReactiveElement: b }),
          (null !== (v = (f = globalThis).reactiveElementVersions) &&
          void 0 !== v
            ? v
            : (f.reactiveElementVersions = [])
          ).push("1.0.0-rc.1");
        const A = b;
        (null !== (S = (P = globalThis).litElementVersions) && void 0 !== S
          ? S
          : (P.litElementVersions = [])
        ).push("3.0.0-rc.1");
        class x extends b {
          constructor() {
            super(...arguments),
              (this.renderOptions = { host: this }),
              (this.Φt = void 0);
          }
          createRenderRoot() {
            var t, e;
            const i = super.createRenderRoot();
            return (
              (null !== (t = (e = this.renderOptions).renderBefore) &&
                void 0 !== t) ||
                (e.renderBefore = i.firstChild),
              i
            );
          }
          update(t) {
            const e = this.render();
            super.update(t),
              (this.Φt = (0, s.sY)(e, this.renderRoot, this.renderOptions));
          }
          connectedCallback() {
            var t;
            super.connectedCallback(),
              null === (t = this.Φt) || void 0 === t || t.setConnected(!0);
          }
          disconnectedCallback() {
            var t;
            super.disconnectedCallback(),
              null === (t = this.Φt) || void 0 === t || t.setConnected(!1);
          }
          render() {
            return s.Jb;
          }
        }
        (x.finalized = !0),
          (x._$litElement$ = !0),
          null === (k = (w = globalThis).litElementHydrateSupport) ||
            void 0 === k ||
            k.call(w, { LitElement: x }),
          null === (C = (E = globalThis).litElementPlatformSupport) ||
            void 0 === C ||
            C.call(E, { LitElement: x });
        const $ = {
          K: (t, e, i) => {
            t.K(e, i);
          },
          L: (t) => t.L,
        };
      },
      409: function (t, e, i) {
        var s =
          (this && this.__decorate) ||
          function (t, e, i, s) {
            var r,
              o = arguments.length,
              n =
                o < 3
                  ? e
                  : null === s
                  ? (s = Object.getOwnPropertyDescriptor(e, i))
                  : s;
            if (
              "object" == typeof Reflect &&
              "function" == typeof Reflect.decorate
            )
              n = Reflect.decorate(t, e, i, s);
            else
              for (var l = t.length - 1; l >= 0; l--)
                (r = t[l]) &&
                  (n = (o < 3 ? r(n) : o > 3 ? r(e, i, n) : r(e, i)) || n);
            return o > 3 && n && Object.defineProperty(e, i, n), n;
          };
        Object.defineProperty(e, "__esModule", { value: !0 }),
          (e.IconparkIconElement = void 0);
        const r = i(249),
          o = i(26),
          n = i(23),
          l = { color: 1, fill: 1, stroke: 1 },
          a = {
            STROKE: { trackAttr: "data-follow-stroke", rawAttr: "stroke" },
            FILL: { trackAttr: "data-follow-fill", rawAttr: "fill" },
          };
        class h extends r.LitElement {
          constructor() {
            super(...arguments),
              (this.name = ""),
              (this.identifyer = ""),
              (this.size = "1em");
          }
          get _width() {
            return this.width || this.size;
          }
          get _height() {
            return this.height || this.size;
          }
          get _stroke() {
            return this.stroke || this.color;
          }
          get _fill() {
            return this.fill || this.color;
          }
          get SVGConfig() {
            return (
              (window.__iconpark__ || {})[this.identifyer] ||
              (window.__iconpark__ || {})[this.name] || {
                viewBox: "0 0 0 0",
                content: "",
              }
            );
          }
          connectedCallback() {
            super.connectedCallback(),
              setTimeout(() => {
                this.monkeyPatch("STROKE", !0), this.monkeyPatch("FILL", !0);
              });
          }
          monkeyPatch(t, e) {
            switch (t) {
              case "STROKE":
                this.updateDOMByHand(
                  this.strokeAppliedNodes,
                  "STROKE",
                  this._stroke,
                  !!e
                );
                break;
              case "FILL":
                this.updateDOMByHand(
                  this.fillAppliedNodes,
                  "FILL",
                  this._fill,
                  !!e
                );
            }
          }
          updateDOMByHand(t, e, i, s) {
            (!i && s) ||
              (t &&
                t.forEach((t) => {
                  (i && i === t.getAttribute(a[e].rawAttr)) ||
                    t.setAttribute(
                      a[e].rawAttr,
                      i || t.getAttribute(a[e].trackAttr)
                    );
                }));
          }
          attributeChangedCallback(t, e, i) {
            super.attributeChangedCallback(t, e, i),
              "name" === t || "identifyer" === t
                ? setTimeout(() => {
                    this.monkeyPatch("STROKE"), this.monkeyPatch("FILL");
                  })
                : l[t] &&
                  (this.monkeyPatch("STROKE"), this.monkeyPatch("FILL"));
          }
          render() {
            return r.svg`<svg width=${this._width} height=${
              this._height
            } preserveAspectRatio="xMidYMid meet" xmlns="http://www.w3.org/2000/svg" fill=${
              this.SVGConfig.fill
            } viewBox=${this.SVGConfig.viewBox}>${n.unsafeSVG(
              this.SVGConfig.content
            )}</svg>`;
          }
        }
        (h.styles = r.css`:host {display: inline-flex; align-items: center; justify-content: center;} :host([spin]) svg {animation: iconpark-spin 1s infinite linear;} :host([spin][rtl]) svg {animation: iconpark-spin-rtl 1s infinite linear;} :host([rtl]) svg {transform: scaleX(-1);} @keyframes iconpark-spin {0% { -webkit-transform: rotate(0); transform: rotate(0);} 100% {-webkit-transform: rotate(360deg); transform: rotate(360deg);}} @keyframes iconpark-spin-rtl {0% {-webkit-transform: scaleX(-1) rotate(0); transform: scaleX(-1) rotate(0);} 100% {-webkit-transform: scaleX(-1) rotate(360deg); transform: scaleX(-1) rotate(360deg);}}`),
          s([o.property({ reflect: !0 })], h.prototype, "name", void 0),
          s(
            [o.property({ reflect: !0, attribute: "icon-id" })],
            h.prototype,
            "identifyer",
            void 0
          ),
          s([o.property({ reflect: !0 })], h.prototype, "color", void 0),
          s([o.property({ reflect: !0 })], h.prototype, "stroke", void 0),
          s([o.property({ reflect: !0 })], h.prototype, "fill", void 0),
          s([o.property({ reflect: !0 })], h.prototype, "size", void 0),
          s([o.property({ reflect: !0 })], h.prototype, "width", void 0),
          s([o.property({ reflect: !0 })], h.prototype, "height", void 0),
          s(
            [o.queryAll(`[${a.STROKE.trackAttr}]`)],
            h.prototype,
            "strokeAppliedNodes",
            void 0
          ),
          s(
            [o.queryAll(`[${a.FILL.trackAttr}]`)],
            h.prototype,
            "fillAppliedNodes",
            void 0
          ),
          (e.IconparkIconElement = h),
          customElements.get("iconpark-icon") ||
            customElements.define("iconpark-icon", h);
      },
    },
    e = {};
  function i(s) {
    var r = e[s];
    if (void 0 !== r) return r.exports;
    var o = (e[s] = { exports: {} });
    return t[s].call(o.exports, o, o.exports, i), o.exports;
  }
  (i.d = (t, e) => {
    for (var s in e)
      i.o(e, s) &&
        !i.o(t, s) &&
        Object.defineProperty(t, s, { enumerable: !0, get: e[s] });
  }),
    (i.o = (t, e) => Object.prototype.hasOwnProperty.call(t, e)),
    (i.r = (t) => {
      "undefined" != typeof Symbol &&
        Symbol.toStringTag &&
        Object.defineProperty(t, Symbol.toStringTag, { value: "Module" }),
        Object.defineProperty(t, "__esModule", { value: !0 });
    }),
    i(409);
})();
